"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { CheckCircle, XCircle } from "lucide-react"

interface QuizContentProps {
  title: string
  description: string
  questions: {
    question: string
    options: string[]
    correctAnswer: number
  }[]
}

export default function QuizContent({ title, description, questions }: QuizContentProps) {
  const [currentQuestion, setCurrentQuestion] = useState(0)
  const [selectedOption, setSelectedOption] = useState<number | null>(null)
  const [showResult, setShowResult] = useState(false)
  const [score, setScore] = useState(0)
  const [quizStarted, setQuizStarted] = useState(false)
  const [quizCompleted, setQuizCompleted] = useState(false)

  const handleStartQuiz = () => {
    setQuizStarted(true)
    setCurrentQuestion(0)
    setScore(0)
    setQuizCompleted(false)
  }

  const handleOptionSelect = (optionIndex: number) => {
    setSelectedOption(optionIndex)
    setShowResult(true)

    if (optionIndex === questions[currentQuestion].correctAnswer) {
      setScore(score + 1)
    }
  }

  const handleNextQuestion = () => {
    setSelectedOption(null)
    setShowResult(false)

    if (currentQuestion < questions.length - 1) {
      setCurrentQuestion(currentQuestion + 1)
    } else {
      setQuizCompleted(true)
    }
  }

  if (!quizStarted) {
    return (
      <div className="space-y-4 p-6 text-center">
        <h2 className="text-2xl font-bold">{title}</h2>
        <p className="text-muted-foreground">{description}</p>
        <p className="font-medium">Total Questions: {questions.length}</p>
        <Button onClick={handleStartQuiz} className="mt-4">
          Start Quiz
        </Button>
      </div>
    )
  }

  if (quizCompleted) {
    return (
      <div className="space-y-4 p-6 text-center">
        <h2 className="text-2xl font-bold">Quiz Completed!</h2>
        <div className="text-5xl font-bold my-8">
          {score} / {questions.length}
        </div>
        <p className="text-lg">
          {score === questions.length
            ? "Perfect score! Excellent work!"
            : score > questions.length / 2
              ? "Good job! You passed the quiz."
              : "Keep practicing to improve your score."}
        </p>
        <Button onClick={handleStartQuiz} className="mt-4">
          Retake Quiz
        </Button>
      </div>
    )
  }

  return (
    <div className="space-y-6 p-4">
      <div className="flex justify-between items-center">
        <h2 className="text-xl font-bold">{title}</h2>
        <span className="text-sm font-medium">
          Question {currentQuestion + 1} of {questions.length}
        </span>
      </div>

      <div className="p-4 border rounded-lg">
        <h3 className="text-lg font-medium mb-4">{questions[currentQuestion].question}</h3>

        <div className="space-y-3">
          {questions[currentQuestion].options.map((option, index) => (
            <button
              key={index}
              onClick={() => !showResult && handleOptionSelect(index)}
              disabled={showResult}
              className={`w-full text-left p-3 rounded-md border transition-colors ${
                selectedOption === index
                  ? index === questions[currentQuestion].correctAnswer
                    ? "border-green-500 bg-green-50"
                    : "border-red-500 bg-red-50"
                  : "hover:bg-muted"
              }`}
            >
              <div className="flex justify-between items-center">
                <span>{option}</span>
                {showResult &&
                  index === selectedOption &&
                  (index === questions[currentQuestion].correctAnswer ? (
                    <CheckCircle className="h-5 w-5 text-green-500" />
                  ) : (
                    <XCircle className="h-5 w-5 text-red-500" />
                  ))}
                {showResult && index === questions[currentQuestion].correctAnswer && index !== selectedOption && (
                  <CheckCircle className="h-5 w-5 text-green-500" />
                )}
              </div>
            </button>
          ))}
        </div>
      </div>

      {showResult && (
        <div className="flex justify-end">
          <Button onClick={handleNextQuestion}>
            {currentQuestion < questions.length - 1 ? "Next Question" : "See Results"}
          </Button>
        </div>
      )}
    </div>
  )
}
