"use client"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"

interface HobbiesDropdownProps {
  children: React.ReactNode
  className?: string
}

export default function HobbiesDropdown({ children, className }: HobbiesDropdownProps) {
  const router = useRouter()
  const [open, setOpen] = useState(false)

  const handleSelect = (hobby: string) => {
    // In a real app, you might want to store this selection in state or context
    console.log(`Selected hobby: ${hobby}`)
    router.push(`/hobbies/${hobby.toLowerCase().replace(/\s+/g, "-")}`)
    setOpen(false)
  }

  return (
    <DropdownMenu open={open} onOpenChange={setOpen}>
      <DropdownMenuTrigger className={className}>{children}</DropdownMenuTrigger>
      <DropdownMenuContent className="w-56">
        <DropdownMenuItem onClick={() => handleSelect("Reading & Writing")}>Reading & Writing</DropdownMenuItem>
        <DropdownMenuItem onClick={() => handleSelect("Drawing")}>Drawing</DropdownMenuItem>
        <DropdownMenuItem onClick={() => handleSelect("Sports")}>Sports</DropdownMenuItem>
        <DropdownMenuItem onClick={() => handleSelect("Travelling")}>Travelling</DropdownMenuItem>
        <DropdownMenuItem onClick={() => handleSelect("Driving")}>Driving</DropdownMenuItem>
        <DropdownMenuItem onClick={() => handleSelect("Cooking")}>Cooking</DropdownMenuItem>
        <DropdownMenuItem onClick={() => handleSelect("Photography")}>Photography</DropdownMenuItem>
        <DropdownMenuItem onClick={() => handleSelect("Gaming")}>Gaming</DropdownMenuItem>
        <DropdownMenuItem onClick={() => handleSelect("Music")}>Music</DropdownMenuItem>
        <DropdownMenuItem onClick={() => handleSelect("Gardening")}>Gardening</DropdownMenuItem>
        <DropdownMenuItem onClick={() => handleSelect("Crafting")}>Crafting</DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  )
}
