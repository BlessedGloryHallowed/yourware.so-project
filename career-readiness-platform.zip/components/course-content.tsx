"use client"

import { useState } from "react"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { BookOpen, CheckCircle } from "lucide-react"

interface CourseContentProps {
  title: string
  description: string
  modules: {
    title: string
    lessons: string[]
    completed?: boolean
  }[]
}

export default function CourseContent({ title, description, modules }: CourseContentProps) {
  const [activeModule, setActiveModule] = useState<number | null>(null)
  const [open, setOpen] = useState(false)

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <h2 className="text-xl font-bold">{title}</h2>
        <Button variant="outline" size="sm">
          Start Course
        </Button>
      </div>

      <p className="text-muted-foreground">{description}</p>

      <div className="space-y-4 mt-6">
        {modules.map((module, index) => (
          <div key={index} className="border rounded-lg p-4">
            <div className="flex justify-between items-center">
              <div className="flex items-center gap-2">
                <BookOpen className="h-5 w-5 text-primary" />
                <h3 className="font-medium">{module.title}</h3>
              </div>
              {module.completed ? (
                <span className="flex items-center text-green-500 text-sm">
                  <CheckCircle className="h-4 w-4 mr-1" /> Completed
                </span>
              ) : (
                <Dialog>
                  <DialogTrigger asChild>
                    <Button variant="ghost" size="sm" onClick={() => setActiveModule(index)}>
                      View Lessons
                    </Button>
                  </DialogTrigger>
                  <DialogContent>
                    <DialogHeader>
                      <DialogTitle>{module.title}</DialogTitle>
                    </DialogHeader>
                    <div className="space-y-2 mt-4">
                      {module.lessons.map((lesson, i) => (
                        <div key={i} className="p-3 border rounded-md flex justify-between items-center">
                          <span>{lesson}</span>
                          <Button size="sm">Start</Button>
                        </div>
                      ))}
                    </div>
                  </DialogContent>
                </Dialog>
              )}
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}
