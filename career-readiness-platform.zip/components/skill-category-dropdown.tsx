"use client"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"

interface SkillCategoryDropdownProps {
  children: React.ReactNode
  className?: string
}

export default function SkillCategoryDropdown({ children, className }: SkillCategoryDropdownProps) {
  const router = useRouter()
  const [open, setOpen] = useState(false)

  const handleSelect = (category: string) => {
    console.log(`Selected skill category: ${category}`)
    router.push(`/skills/category/${category.toLowerCase().replace(/\s+/g, "-")}`)
    setOpen(false)
  }

  return (
    <DropdownMenu open={open} onOpenChange={setOpen}>
      <DropdownMenuTrigger className={className}>{children}</DropdownMenuTrigger>
      <DropdownMenuContent className="w-56">
        <DropdownMenuItem onClick={() => handleSelect("Programming")}>Programming</DropdownMenuItem>
        <DropdownMenuItem onClick={() => handleSelect("Communication")}>Communication</DropdownMenuItem>
        <DropdownMenuItem onClick={() => handleSelect("Design")}>Design</DropdownMenuItem>
        <DropdownMenuItem onClick={() => handleSelect("Leadership")}>Leadership</DropdownMenuItem>
        <DropdownMenuItem onClick={() => handleSelect("Problem Solving")}>Problem Solving</DropdownMenuItem>
        <DropdownMenuItem onClick={() => handleSelect("Critical Thinking")}>Critical Thinking</DropdownMenuItem>
        <DropdownMenuItem onClick={() => handleSelect("Data Analysis")}>Data Analysis</DropdownMenuItem>
        <DropdownMenuItem onClick={() => handleSelect("Project Management")}>Project Management</DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  )
}
