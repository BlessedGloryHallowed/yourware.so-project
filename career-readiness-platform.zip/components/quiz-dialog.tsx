"use client"

import type React from "react"

import { useState } from "react"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"

interface QuizDialogProps {
  children: React.ReactNode
  category?: string
  onSelect: (quiz: string) => void
}

export default function QuizDialog({ children, category = "all", onSelect }: QuizDialogProps) {
  const [open, setOpen] = useState(false)

  const handleSelect = (quiz: string) => {
    onSelect(quiz)
    setOpen(false)
  }

  // Different quizzes based on category
  const getQuizzes = () => {
    switch (category) {
      case "technical":
        return ["Programming Fundamentals", "Web Development", "Data Structures", "Algorithms", "Database Design"]
      case "soft-skills":
        return [
          "Effective Communication",
          "Team Collaboration",
          "Leadership Skills",
          "Time Management",
          "Problem Solving",
        ]
      case "career":
        return [
          "Resume Building",
          "Interview Preparation",
          "Career Planning",
          "Networking Skills",
          "Professional Development",
        ]
      default:
        return [
          "Programming Fundamentals",
          "Effective Communication",
          "Resume Building & Interviews",
          "Project Management",
          "Data Analysis",
        ]
    }
  }

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger>{children}</DialogTrigger>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Select Quiz</DialogTitle>
        </DialogHeader>
        <div className="grid gap-4 py-4">
          {getQuizzes().map((quiz) => (
            <Button
              key={quiz}
              variant="outline"
              onClick={() => handleSelect(quiz)}
              className="justify-start text-left font-normal"
            >
              {quiz}
            </Button>
          ))}
        </div>
      </DialogContent>
    </Dialog>
  )
}
