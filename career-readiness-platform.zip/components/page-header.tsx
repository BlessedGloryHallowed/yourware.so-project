import type React from "react"
import { ChevronRight } from "lucide-react"

interface PageHeaderProps {
  title: string
  actions?: React.ReactNode
}

export default function PageHeader({ title, actions }: PageHeaderProps) {
  return (
    <div className="flex items-center justify-between p-4 border-b border-border">
      <div className="flex items-center">
        <div className="flex items-center justify-center w-10 h-10 rounded-full bg-primary text-white">
          <ChevronRight className="h-6 w-6" />
        </div>
        <h1 className="ml-4 text-2xl font-bold text-foreground">{title}</h1>
      </div>
      {actions && <div className="flex space-x-2">{actions}</div>}
    </div>
  )
}
