"use client"

import type React from "react"

import { useState } from "react"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"

interface CourseDialogProps {
  children: React.ReactNode
  category: string
  onSelect: (course: string) => void
}

export default function CourseDialog({ children, category, onSelect }: CourseDialogProps) {
  const [open, setOpen] = useState(false)

  const handleSelect = (course: string) => {
    onSelect(course)
    setOpen(false)
  }

  // Different courses based on category
  const getCourses = () => {
    switch (category.toLowerCase()) {
      case "programming":
        return [
          "JavaScript Fundamentals",
          "Python for Beginners",
          "Web Development Bootcamp",
          "Data Structures & Algorithms",
          "Mobile App Development",
        ]
      case "communication":
        return [
          "Effective Communication Skills",
          "Public Speaking",
          "Business Writing",
          "Interpersonal Communication",
          "Presentation Skills",
        ]
      case "design":
        return ["UI/UX Design", "Graphic Design", "Web Design", "Product Design", "Design Thinking"]
      default:
        return ["Course 1", "Course 2", "Course 3", "Course 4", "Course 5"]
    }
  }

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger>{children}</DialogTrigger>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Select {category} Course</DialogTitle>
        </DialogHeader>
        <div className="grid gap-4 py-4">
          {getCourses().map((course) => (
            <Button
              key={course}
              variant="outline"
              onClick={() => handleSelect(course)}
              className="justify-start text-left font-normal"
            >
              {course}
            </Button>
          ))}
        </div>
      </DialogContent>
    </Dialog>
  )
}
