"use client"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"

interface CourseDropdownProps {
  children: React.ReactNode
  className?: string
  category: string
}

export default function CourseDropdown({ children, className, category }: CourseDropdownProps) {
  const router = useRouter()
  const [open, setOpen] = useState(false)

  const handleSelect = (course: string) => {
    console.log(`Selected course: ${course} in category: ${category}`)
    router.push(`/courses/${category.toLowerCase().replace(/\s+/g, "-")}/${course.toLowerCase().replace(/\s+/g, "-")}`)
    setOpen(false)
  }

  // Different courses based on category
  const getCourses = () => {
    switch (category) {
      case "programming":
        return [
          "JavaScript Fundamentals",
          "Python for Beginners",
          "Web Development Bootcamp",
          "Data Structures & Algorithms",
          "Mobile App Development",
        ]
      case "communication":
        return [
          "Effective Communication Skills",
          "Public Speaking",
          "Business Writing",
          "Interpersonal Communication",
          "Presentation Skills",
        ]
      case "design":
        return ["UI/UX Design", "Graphic Design", "Web Design", "Product Design", "Design Thinking"]
      default:
        return ["Course 1", "Course 2", "Course 3", "Course 4", "Course 5"]
    }
  }

  return (
    <DropdownMenu open={open} onOpenChange={setOpen}>
      <DropdownMenuTrigger className={className}>{children}</DropdownMenuTrigger>
      <DropdownMenuContent className="w-56">
        {getCourses().map((course) => (
          <DropdownMenuItem key={course} onClick={() => handleSelect(course)}>
            {course}
          </DropdownMenuItem>
        ))}
      </DropdownMenuContent>
    </DropdownMenu>
  )
}
