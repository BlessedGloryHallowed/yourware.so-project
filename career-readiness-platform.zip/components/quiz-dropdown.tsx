"use client"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"

interface QuizDropdownProps {
  children: React.ReactNode
  className?: string
  category?: string
}

export default function QuizDropdown({ children, className, category = "all" }: QuizDropdownProps) {
  const router = useRouter()
  const [open, setOpen] = useState(false)

  const handleSelect = (quiz: string) => {
    console.log(`Selected quiz: ${quiz}`)
    router.push(`/quizzes/take/${quiz.toLowerCase().replace(/\s+/g, "-")}`)
    setOpen(false)
  }

  // Different quizzes based on category
  const getQuizzes = () => {
    switch (category) {
      case "technical":
        return ["Programming Fundamentals", "Web Development", "Data Structures", "Algorithms", "Database Design"]
      case "soft-skills":
        return [
          "Effective Communication",
          "Team Collaboration",
          "Leadership Skills",
          "Time Management",
          "Problem Solving",
        ]
      case "career":
        return [
          "Resume Building",
          "Interview Preparation",
          "Career Planning",
          "Networking Skills",
          "Professional Development",
        ]
      default:
        return [
          "Programming Fundamentals",
          "Effective Communication",
          "Resume Building & Interviews",
          "Project Management",
          "Data Analysis",
        ]
    }
  }

  return (
    <DropdownMenu open={open} onOpenChange={setOpen}>
      <DropdownMenuTrigger className={className}>{children}</DropdownMenuTrigger>
      <DropdownMenuContent className="w-56">
        {getQuizzes().map((quiz) => (
          <DropdownMenuItem key={quiz} onClick={() => handleSelect(quiz)}>
            {quiz}
          </DropdownMenuItem>
        ))}
      </DropdownMenuContent>
    </DropdownMenu>
  )
}
