"use client"

import type React from "react"

import { useState } from "react"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"

interface StudyFieldDialogProps {
  children: React.ReactNode
  type: "current" | "future"
  onSelect: (field: string) => void
}

export default function StudyFieldDialog({ children, type, onSelect }: StudyFieldDialogProps) {
  const [open, setOpen] = useState(false)

  const handleSelect = (field: string) => {
    onSelect(field)
    setOpen(false)
  }

  const studyFields = [
    "Computer Science & IT",
    "Engineering",
    "Business & Management",
    "Design & Creative",
    "Data Science & Analytics",
    "Languages",
    "Education",
    "Philosophy",
    "Music",
    "Fine Arts",
    "Medicine & Healthcare",
    "Law & Legal Studies",
  ]

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger>{children}</DialogTrigger>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Select {type === "current" ? "Current" : "Future"} Study Field</DialogTitle>
        </DialogHeader>
        <div className="grid gap-4 py-4">
          {studyFields.map((field) => (
            <Button
              key={field}
              variant="outline"
              onClick={() => handleSelect(field)}
              className="justify-start text-left font-normal"
            >
              {field}
            </Button>
          ))}
        </div>
      </DialogContent>
    </Dialog>
  )
}
