"use client"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"

interface StudyFieldDropdownProps {
  children: React.ReactNode
  className?: string
  type: "current" | "future"
}

export default function StudyFieldDropdown({ children, className, type }: StudyFieldDropdownProps) {
  const router = useRouter()
  const [open, setOpen] = useState(false)

  const handleSelect = (field: string) => {
    // In a real app, you might want to store this selection in state or context
    console.log(`Selected ${type} field: ${field}`)
    router.push(`/${type}-study/${field.toLowerCase().replace(/\s+/g, "-").replace(/&/g, "and")}`)
    setOpen(false)
  }

  return (
    <DropdownMenu open={open} onOpenChange={setOpen}>
      <DropdownMenuTrigger className={className}>{children}</DropdownMenuTrigger>
      <DropdownMenuContent className="w-56">
        <DropdownMenuItem onClick={() => handleSelect("Computer Science & IT")}>Computer Science & IT</DropdownMenuItem>
        <DropdownMenuItem onClick={() => handleSelect("Engineering")}>Engineering</DropdownMenuItem>
        <DropdownMenuItem onClick={() => handleSelect("Business & Management")}>Business & Management</DropdownMenuItem>
        <DropdownMenuItem onClick={() => handleSelect("Design & Creative")}>Design & Creative</DropdownMenuItem>
        <DropdownMenuItem onClick={() => handleSelect("Data Science & Analytics")}>
          Data Science & Analytics
        </DropdownMenuItem>
        <DropdownMenuItem onClick={() => handleSelect("Languages")}>Languages</DropdownMenuItem>
        <DropdownMenuItem onClick={() => handleSelect("Education")}>Education</DropdownMenuItem>
        <DropdownMenuItem onClick={() => handleSelect("Philosophy")}>Philosophy</DropdownMenuItem>
        <DropdownMenuItem onClick={() => handleSelect("Music")}>Music</DropdownMenuItem>
        <DropdownMenuItem onClick={() => handleSelect("Fine Arts")}>Fine Arts</DropdownMenuItem>
        <DropdownMenuItem onClick={() => handleSelect("Medicine & Healthcare")}>Medicine & Healthcare</DropdownMenuItem>
        <DropdownMenuItem onClick={() => handleSelect("Law & Legal Studies")}>Law & Legal Studies</DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  )
}
