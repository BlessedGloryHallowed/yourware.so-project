"use client"

import type React from "react"

import { useState } from "react"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"

interface SkillCategoryDialogProps {
  children: React.ReactNode
  onSelect: (category: string) => void
}

export default function SkillCategoryDialog({ children, onSelect }: SkillCategoryDialogProps) {
  const [open, setOpen] = useState(false)

  const handleSelect = (category: string) => {
    onSelect(category)
    setOpen(false)
  }

  const categories = [
    "Programming",
    "Communication",
    "Design",
    "Leadership",
    "Problem Solving",
    "Critical Thinking",
    "Data Analysis",
    "Project Management",
  ]

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger>{children}</DialogTrigger>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Select Skill Category</DialogTitle>
        </DialogHeader>
        <div className="grid gap-4 py-4">
          {categories.map((category) => (
            <Button
              key={category}
              variant="outline"
              onClick={() => handleSelect(category)}
              className="justify-start text-left font-normal"
            >
              {category}
            </Button>
          ))}
        </div>
      </DialogContent>
    </Dialog>
  )
}
