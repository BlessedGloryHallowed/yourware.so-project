"use client"

import type React from "react"

import { useState } from "react"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"

interface HobbiesDialogProps {
  children: React.ReactNode
  onSelect: (hobby: string) => void
}

export default function HobbiesDialog({ children, onSelect }: HobbiesDialogProps) {
  const [open, setOpen] = useState(false)

  const handleSelect = (hobby: string) => {
    onSelect(hobby)
    setOpen(false)
  }

  const hobbies = [
    "Reading & Writing",
    "Drawing",
    "Sports",
    "Travelling",
    "Driving",
    "Cooking",
    "Photography",
    "Gaming",
    "Music",
    "Gardening",
    "Crafting",
  ]

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger>{children}</DialogTrigger>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Select Hobby</DialogTitle>
        </DialogHeader>
        <div className="grid gap-4 py-4">
          {hobbies.map((hobby) => (
            <Button
              key={hobby}
              variant="outline"
              onClick={() => handleSelect(hobby)}
              className="justify-start text-left font-normal"
            >
              {hobby}
            </Button>
          ))}
        </div>
      </DialogContent>
    </Dialog>
  )
}
