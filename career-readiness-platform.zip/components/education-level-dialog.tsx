"use client"

import type React from "react"

import { useState } from "react"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"

interface EducationLevelDialogProps {
  children: React.ReactNode
  onSelect: (level: string) => void
}

export default function EducationLevelDialog({ children, onSelect }: EducationLevelDialogProps) {
  const [open, setOpen] = useState(false)

  const handleSelect = (level: string) => {
    onSelect(level)
    setOpen(false)
  }

  const educationLevels = ["High School", "Diploma", "Undergraduate", "Masters", "PhD", "Working Professional"]

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger>{children}</DialogTrigger>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Select Education Level</DialogTitle>
        </DialogHeader>
        <div className="grid gap-4 py-4">
          {educationLevels.map((level) => (
            <Button
              key={level}
              variant="outline"
              onClick={() => handleSelect(level)}
              className="justify-start text-left font-normal"
            >
              {level}
            </Button>
          ))}
        </div>
      </DialogContent>
    </Dialog>
  )
}
