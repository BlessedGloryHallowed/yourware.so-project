"use client"

import Link from "next/link"
import { usePathname } from "next/navigation"
import { BookOpen, Award, BarChart2, Briefcase, Settings, Lightbulb, Home, ChevronRight } from "lucide-react"

export default function Sidebar() {
  const pathname = usePathname()

  const routes = [
    { name: "Dashboard", path: "/", icon: Home },
    { name: "Knowledge Quizzes", path: "/quizzes", icon: BookOpen },
    { name: "Skills Assessment", path: "/skills", icon: BarChart2 },
    { name: "Study Progress", path: "/progress", icon: ChevronRight },
    { name: "Career Path", path: "/career", icon: Briefcase },
    { name: "Learning Path", path: "/learning", icon: ChevronRight },
    { name: "Fun Facts & Knowledge Boosters", path: "/fun-facts", icon: Lightbulb },
    { name: "Certificates & Achievements", path: "/certificates", icon: Award },
    { name: "Settings", path: "/settings", icon: Settings },
  ]

  return (
    <div className="hidden md:flex md:w-64 md:flex-col">
      <div className="flex flex-col flex-grow border-r border-border bg-background pt-5">
        <div className="flex items-center flex-shrink-0 px-4">
          <span className="text-xl font-bold">Career Ready</span>
        </div>
        <div className="mt-5 flex-1 flex flex-col">
          <nav className="flex-1 px-2 pb-4 space-y-1">
            {routes.map((route) => {
              const isActive = pathname === route.path
              const Icon = route.icon

              return (
                <Link
                  key={route.path}
                  href={route.path}
                  className={`group flex items-center px-2 py-2 text-sm font-medium rounded-md ${
                    isActive ? "bg-primary text-white" : "text-foreground hover:bg-muted"
                  }`}
                >
                  <Icon className={`mr-3 h-5 w-5 ${isActive ? "text-white" : "text-muted-foreground"}`} />
                  {route.name}
                </Link>
              )
            })}
          </nav>
        </div>
      </div>
    </div>
  )
}
