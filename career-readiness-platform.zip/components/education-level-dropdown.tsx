"use client"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"

interface EducationLevelDropdownProps {
  children: React.ReactNode
  className?: string
}

export default function EducationLevelDropdown({ children, className }: EducationLevelDropdownProps) {
  const router = useRouter()
  const [open, setOpen] = useState(false)

  const handleSelect = (level: string) => {
    // In a real app, you might want to store this selection in state or context
    console.log(`Selected education level: ${level}`)
    router.push(`/education/${level.toLowerCase().replace(/\s+/g, "-")}`)
    setOpen(false)
  }

  return (
    <DropdownMenu open={open} onOpenChange={setOpen}>
      <DropdownMenuTrigger className={className}>{children}</DropdownMenuTrigger>
      <DropdownMenuContent className="w-56">
        <DropdownMenuItem onClick={() => handleSelect("High School")}>High School</DropdownMenuItem>
        <DropdownMenuItem onClick={() => handleSelect("Diploma")}>Diploma</DropdownMenuItem>
        <DropdownMenuItem onClick={() => handleSelect("Undergraduate")}>Undergraduate</DropdownMenuItem>
        <DropdownMenuItem onClick={() => handleSelect("Masters")}>Masters</DropdownMenuItem>
        <DropdownMenuItem onClick={() => handleSelect("PhD")}>PhD</DropdownMenuItem>
        <DropdownMenuItem onClick={() => handleSelect("Working Professional")}>Working Professional</DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  )
}
