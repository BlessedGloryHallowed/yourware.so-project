import PageHeader from "@/components/page-header"
import { Button } from "@/components/ui/button"
import { Lightbulb, Code, Bookmark, Share2 } from "lucide-react"

export default function FunFactsPage() {
  return (
    <div className="flex flex-col min-h-screen">
      <PageHeader
        title="Fun Facts & Knowledge Boosters"
        actions={
          <>
            <Button variant="outline" className="flex items-center gap-2">
              <span>Filter Topics</span>
            </Button>
            <Button className="flex items-center gap-2">
              <span>Get New Fact</span>
            </Button>
          </>
        }
      />

      <div className="grid md:grid-cols-3 gap-6 p-6">
        <div className="md:col-span-2">
          <div className="card">
            <h2 className="text-lg font-semibold mb-4">Today's Learning Bites</h2>

            <div className="w-48 mb-4">
              <select className="select">
                <option>All Categories</option>
                <option>Productivity</option>
                <option>Tech History</option>
                <option>Career Tips</option>
              </select>
            </div>

            <div className="space-y-6">
              <div className="border-b pb-4">
                <div className="flex items-start gap-4">
                  <div className="flex items-center justify-center w-10 h-10 rounded-full bg-blue-500 text-white mt-1">
                    <Lightbulb className="h-5 w-5" />
                  </div>

                  <div className="flex-1">
                    <h3 className="font-semibold text-lg mb-2">Did You Know?</h3>
                    <p className="mb-4">
                      The average professional spends 28% of their workday reading and answering emails. Improving your
                      email management skills can save you up to 10 hours a week!
                    </p>

                    <div className="flex justify-between items-center">
                      <div>
                        <span className="inline-block bg-cyan-100 text-cyan-800 text-xs font-medium px-2.5 py-0.5 rounded">
                          Productivity
                        </span>
                      </div>

                      <div className="flex gap-2">
                        <Button variant="outline" size="sm" className="flex items-center gap-1">
                          <Bookmark className="h-4 w-4" />
                          <span>Save</span>
                        </Button>
                        <Button variant="outline" size="sm" className="flex items-center gap-1">
                          <Share2 className="h-4 w-4" />
                          <span>Share</span>
                        </Button>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              <div className="border-b pb-4">
                <div className="flex items-start gap-4">
                  <div className="flex items-center justify-center w-10 h-10 rounded-full bg-green-500 text-white mt-1">
                    <Code className="h-5 w-5" />
                  </div>

                  <div className="flex-1">
                    <h3 className="font-semibold text-lg mb-2">Programming Insight</h3>
                    <p className="mb-4">
                      Python was not named after the snake, but after the British comedy show "Monty Python's Flying
                      Circus." Guido van Rossum, the creator of Python, was a big fan of the show!
                    </p>

                    <div className="flex justify-between items-center">
                      <div>
                        <span className="inline-block bg-cyan-100 text-cyan-800 text-xs font-medium px-2.5 py-0.5 rounded">
                          Tech History
                        </span>
                      </div>

                      <div className="flex gap-2">
                        <Button variant="outline" size="sm" className="flex items-center gap-1">
                          <Bookmark className="h-4 w-4" />
                          <span>Save</span>
                        </Button>
                        <Button variant="outline" size="sm" className="flex items-center gap-1">
                          <Share2 className="h-4 w-4" />
                          <span>Share</span>
                        </Button>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="space-y-6">
          <div className="card">
            <h2 className="text-lg font-semibold mb-4">Fact of the Day</h2>

            <div className="flex flex-col items-center">
              <div className="flex items-center justify-center w-16 h-16 rounded-full bg-blue-500 text-white mb-4">
                <Lightbulb className="h-8 w-8" />
              </div>

              <h3 className="text-xl font-semibold text-center mb-4">Growth Mindset Impact</h3>

              <p className="text-center mb-6">
                People with a "growth mindset" who believe abilities can be developed through hard work achieve 11%
                higher grades than those with a "fixed mindset" who believe talents are innate gifts.
              </p>

              <Button variant="default" size="sm">
                Learn More
              </Button>
            </div>
          </div>

          <div className="card">
            <h2 className="text-lg font-semibold mb-4">Saved Facts</h2>
            <div className="flex flex-col items-center justify-center h-32 bg-muted rounded-lg">
              <p className="text-muted-foreground">Save facts to view them later</p>
              <Button variant="outline" className="mt-2">
                Browse All Facts
              </Button>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
