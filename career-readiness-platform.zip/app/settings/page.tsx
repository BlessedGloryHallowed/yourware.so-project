import PageHeader from "@/components/page-header"
import { Button } from "@/components/ui/button"
import { Camera } from "lucide-react"
import Image from "next/image"

export default function SettingsPage() {
  return (
    <div className="flex flex-col min-h-screen">
      <PageHeader
        title="Settings"
        actions={
          <Button className="flex items-center gap-2">
            <span>Save Changes</span>
          </Button>
        }
      />

      <div className="grid md:grid-cols-2 gap-6 p-6">
        <div className="card">
          <h2 className="text-lg font-semibold mb-6">User Profile Settings</h2>

          <div className="flex flex-col items-center mb-6">
            <div className="relative mb-4">
              <div className="w-24 h-24 rounded-full overflow-hidden border-4 border-white shadow-md">
                <Image
                  src="/placeholder.svg?height=96&width=96"
                  alt="Profile"
                  width={96}
                  height={96}
                  className="object-cover"
                />
              </div>
              <button className="absolute bottom-0 right-0 bg-primary text-white rounded-full p-2 shadow-md">
                <Camera className="h-4 w-4" />
              </button>
            </div>
            <p className="text-sm text-muted-foreground">Click on the camera icon to change your profile picture</p>
          </div>

          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium mb-1">Full Name</label>
              <input type="text" className="input" defaultValue="John Smith" />
            </div>

            <div>
              <label className="block text-sm font-medium mb-1">Email Address</label>
              <input type="email" className="input" defaultValue="john.smith@example.com" />
            </div>

            <div>
              <label className="block text-sm font-medium mb-1">Education Level</label>
              <select className="select">
                <option>Bachelor's Degree</option>
                <option>Master's Degree</option>
                <option>PhD</option>
                <option>High School</option>
                <option>Associate's Degree</option>
              </select>
            </div>
          </div>
        </div>

        <div className="card">
          <h2 className="text-lg font-semibold mb-6">Account Settings</h2>

          <div className="space-y-6">
            <div>
              <label className="block text-sm font-medium mb-1">Language</label>
              <select className="select">
                <option>English</option>
                <option>Spanish</option>
                <option>French</option>
                <option>German</option>
                <option>Chinese</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium mb-1">Time Zone</label>
              <select className="select">
                <option>GMT-5 (Eastern Time)</option>
                <option>GMT-6 (Central Time)</option>
                <option>GMT-7 (Mountain Time)</option>
                <option>GMT-8 (Pacific Time)</option>
                <option>GMT+0 (UTC)</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium mb-2">Theme</label>
              <div className="flex gap-4">
                <label className="flex items-center">
                  <input type="radio" name="theme" className="mr-2" defaultChecked />
                  <span>Light</span>
                </label>
                <label className="flex items-center">
                  <input type="radio" name="theme" className="mr-2" />
                  <span>Dark</span>
                </label>
                <label className="flex items-center">
                  <input type="radio" name="theme" className="mr-2" />
                  <span>System</span>
                </label>
              </div>
            </div>

            <div>
              <h3 className="text-sm font-medium mb-2">Privacy Settings</h3>

              <div className="space-y-2">
                <label className="flex items-center">
                  <input type="checkbox" className="mr-2" defaultChecked />
                  <span>Public Profile</span>
                </label>

                <label className="flex items-center">
                  <input type="checkbox" className="mr-2" defaultChecked />
                  <span>Show Progress to Others</span>
                </label>

                <label className="flex items-center">
                  <input type="checkbox" className="mr-2" defaultChecked />
                  <span>Allow Data Collection for Personalization</span>
                </label>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
