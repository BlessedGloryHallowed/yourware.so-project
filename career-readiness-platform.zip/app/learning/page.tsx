import Link from "next/link"
import PageHeader from "@/components/page-header"
import { Button } from "@/components/ui/button"
import { Share2 } from "lucide-react"

export default function LearningPage() {
  return (
    <div className="flex flex-col min-h-screen">
      <PageHeader
        title="Learning Path"
        actions={
          <>
            <Button variant="outline" className="flex items-center gap-2">
              <Share2 className="h-4 w-4" />
              <span>Share Journey</span>
            </Button>
            <Link href="https://www.coursera.org/browse/information-technology/software-development" target="_blank">
              <Button className="flex items-center gap-2">
                <span>Add New Skill</span>
              </Button>
            </Link>
          </>
        }
      />

      <div className="p-6">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
          <Link href="https://www.edx.org/search?tab=course" target="_blank" className="block">
            <div className="bg-blue-500 text-white rounded-lg p-6 h-full transition-transform hover:scale-105">
              <h2 className="text-2xl font-bold mb-2">School Level</h2>
              <p className="text-sm mb-4">Select your current education</p>
              <div className="w-full bg-blue-400 rounded-full h-2 mb-2">
                <div className="bg-white h-2 rounded-full" style={{ width: "60%" }}></div>
              </div>
            </div>
          </Link>

          <Link href="https://www.coursera.org/browse" target="_blank" className="block">
            <div className="bg-pink-500 text-white rounded-lg p-6 h-full transition-transform hover:scale-105">
              <h2 className="text-2xl font-bold mb-2">Current Study</h2>
              <p className="text-sm mb-4">Your field of study</p>
              <div className="w-full bg-pink-400 rounded-full h-2 mb-2">
                <div className="bg-white h-2 rounded-full" style={{ width: "70%" }}></div>
              </div>
            </div>
          </Link>

          <Link href="https://www.futurelearn.com/subjects" target="_blank" className="block">
            <div className="bg-cyan-500 text-white rounded-lg p-6 h-full transition-transform hover:scale-105">
              <h2 className="text-2xl font-bold mb-2">Future Field</h2>
              <p className="text-sm mb-4">Preferred area of study</p>
              <div className="w-full bg-cyan-400 rounded-full h-2 mb-2">
                <div className="bg-white h-2 rounded-full" style={{ width: "40%" }}></div>
              </div>
            </div>
          </Link>

          <Link href="https://www.skillshare.com/browse" target="_blank" className="block">
            <div className="bg-purple-500 text-white rounded-lg p-6 h-full transition-transform hover:scale-105">
              <h2 className="text-2xl font-bold mb-2">Hobbies</h2>
              <p className="text-sm mb-4">Your interests & activities</p>
              <div className="w-full bg-purple-400 rounded-full h-2 mb-2">
                <div className="bg-white h-2 rounded-full" style={{ width: "80%" }}></div>
              </div>
            </div>
          </Link>
        </div>

        <div className="grid md:grid-cols-2 gap-6">
          <div className="card">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-lg font-semibold">Skill Development Overview</h2>

              <div className="w-48">
                <select className="select">
                  <option>Last 30 Days</option>
                  <option>Last 3 Months</option>
                  <option>Last 6 Months</option>
                  <option>Last Year</option>
                </select>
              </div>
            </div>

            <div className="text-center mb-4">
              <h3 className="text-sm font-medium text-muted-foreground">Skill Development Progress</h3>
            </div>

            <div className="h-64 w-full">
              <div className="relative h-full w-full">
                <svg viewBox="0 0 400 200" className="w-full h-full">
                  <g transform="translate(0,10)">
                    <g className="x-axis" transform="translate(0,160)">
                      <line x1="50" y1="0" x2="380" y2="0" stroke="#e2e8f0"></line>
                      <g transform="translate(50,0)">
                        <line y2="6" stroke="#e2e8f0"></line>
                        <text y="20" textAnchor="middle" fontSize="10" fill="#64748b">
                          Jan
                        </text>
                      </g>
                      <g transform="translate(105,0)">
                        <line y2="6" stroke="#e2e8f0"></line>
                        <text y="20" textAnchor="middle" fontSize="10" fill="#64748b">
                          Feb
                        </text>
                      </g>
                      <g transform="translate(160,0)">
                        <line y2="6" stroke="#e2e8f0"></line>
                        <text y="20" textAnchor="middle" fontSize="10" fill="#64748b">
                          Mar
                        </text>
                      </g>
                      <g transform="translate(215,0)">
                        <line y2="6" stroke="#e2e8f0"></line>
                        <text y="20" textAnchor="middle" fontSize="10" fill="#64748b">
                          Apr
                        </text>
                      </g>
                      <g transform="translate(270,0)">
                        <line y2="6" stroke="#e2e8f0"></line>
                        <text y="20" textAnchor="middle" fontSize="10" fill="#64748b">
                          May
                        </text>
                      </g>
                      <g transform="translate(325,0)">
                        <line y2="6" stroke="#e2e8f0"></line>
                        <text y="20" textAnchor="middle" fontSize="10" fill="#64748b">
                          Jun
                        </text>
                      </g>
                      <g transform="translate(380,0)">
                        <line y2="6" stroke="#e2e8f0"></line>
                        <text y="20" textAnchor="middle" fontSize="10" fill="#64748b">
                          Jul
                        </text>
                      </g>
                    </g>
                    <g className="y-axis">
                      <line x1="50" y1="0" x2="50" y2="160" stroke="#e2e8f0"></line>
                      <g transform="translate(0,160)">
                        <line x2="-6" stroke="#e2e8f0"></line>
                        <text x="-10" y="5" textAnchor="end" fontSize="10" fill="#64748b">
                          0
                        </text>
                      </g>
                      <g transform="translate(0,120)">
                        <line x2="-6" stroke="#e2e8f0"></line>
                        <text x="-10" y="5" textAnchor="end" fontSize="10" fill="#64748b">
                          20
                        </text>
                      </g>
                      <g transform="translate(0,80)">
                        <line x2="-6" stroke="#e2e8f0"></line>
                        <text x="-10" y="5" textAnchor="end" fontSize="10" fill="#64748b">
                          40
                        </text>
                      </g>
                      <g transform="translate(0,40)">
                        <line x2="-6" stroke="#e2e8f0"></line>
                        <text x="-10" y="5" textAnchor="end" fontSize="10" fill="#64748b">
                          60
                        </text>
                      </g>
                      <g transform="translate(0,0)">
                        <line x2="-6" stroke="#e2e8f0"></line>
                        <text x="-10" y="5" textAnchor="end" fontSize="10" fill="#64748b">
                          80
                        </text>
                      </g>
                    </g>

                    <path
                      d="M50,120 L105,100 L160,90 L215,70 L270,50 L325,40 L380,30"
                      fill="none"
                      stroke="#3b82f6"
                      strokeWidth="2"
                    ></path>
                    <path
                      d="M50,130 L105,110 L160,95 L215,80 L270,60 L325,45 L380,35"
                      fill="none"
                      stroke="#06b6d4"
                      strokeWidth="2"
                    ></path>

                    <circle cx="50" cy="120" r="3" fill="#3b82f6"></circle>
                    <circle cx="105" cy="100" r="3" fill="#3b82f6"></circle>
                    <circle cx="160" cy="90" r="3" fill="#3b82f6"></circle>
                    <circle cx="215" cy="70" r="3" fill="#3b82f6"></circle>
                    <circle cx="270" cy="50" r="3" fill="#3b82f6"></circle>
                    <circle cx="325" cy="40" r="3" fill="#3b82f6"></circle>
                    <circle cx="380" cy="30" r="3" fill="#3b82f6"></circle>

                    <circle cx="50" cy="130" r="3" fill="#06b6d4"></circle>
                    <circle cx="105" cy="110" r="3" fill="#06b6d4"></circle>
                    <circle cx="160" cy="95" r="3" fill="#06b6d4"></circle>
                    <circle cx="215" cy="80" r="3" fill="#06b6d4"></circle>
                    <circle cx="270" cy="60" r="3" fill="#06b6d4"></circle>
                    <circle cx="325" cy="45" r="3" fill="#06b6d4"></circle>
                    <circle cx="380" cy="35" r="3" fill="#06b6d4"></circle>
                  </g>
                </svg>
              </div>
            </div>

            <div className="flex justify-center mt-4">
              <div className="flex items-center gap-4">
                <Link
                  href="https://www.codecademy.com/catalog/subject/all"
                  target="_blank"
                  className="flex items-center gap-1 hover:underline"
                >
                  <div className="w-3 h-3 bg-blue-500 rounded-sm"></div>
                  <span className="text-xs">Technical Skills</span>
                </Link>
                <Link
                  href="https://www.linkedin.com/learning/topics/communication"
                  target="_blank"
                  className="flex items-center gap-1 hover:underline"
                >
                  <div className="w-3 h-3 bg-cyan-500 rounded-sm"></div>
                  <span className="text-xs">Soft Skills</span>
                </Link>
              </div>
            </div>
          </div>

          <div className="card">
            <h2 className="text-lg font-semibold mb-4">Skill Categories</h2>

            <div className="flex justify-center items-center h-64">
              <svg viewBox="0 0 200 200" className="w-64 h-64">
                <defs>
                  <mask id="donutMask">
                    <rect x="0" y="0" width="200" height="200" fill="white" />
                    <circle cx="100" cy="100" r="50" fill="black" />
                  </mask>
                </defs>

                <a href="https://www.freecodecamp.org/" target="_blank" rel="noreferrer">
                  <path d="M100,100 L100,0 A100,100 0 0,1 175,50 Z" fill="#3b82f6"></path>
                </a>
                <a href="https://www.coursera.org/courses?query=communication" target="_blank" rel="noreferrer">
                  <path d="M100,100 L175,50 A100,100 0 0,1 150,150 Z" fill="#f43f5e"></path>
                </a>
                <a href="https://www.udemy.com/courses/design/" target="_blank" rel="noreferrer">
                  <path d="M100,100 L150,150 A100,100 0 0,1 50,150 Z" fill="#06b6d4"></path>
                </a>
                <a href="https://www.edx.org/learn/leadership" target="_blank" rel="noreferrer">
                  <path d="M100,100 L50,150 A100,100 0 0,1 25,50 Z" fill="#8b5cf6"></path>
                </a>
                <a href="https://www.khanacademy.org/" target="_blank" rel="noreferrer">
                  <path d="M100,100 L25,50 A100,100 0 0,1 100,0 Z" fill="#3b82f6"></path>
                </a>
              </svg>
            </div>

            <div className="flex justify-center mt-4">
              <div className="grid grid-cols-2 gap-x-8 gap-y-2">
                <Link
                  href="https://www.freecodecamp.org/"
                  target="_blank"
                  className="flex items-center gap-1 hover:underline"
                >
                  <div className="w-3 h-3 bg-blue-500 rounded-sm"></div>
                  <span className="text-xs">Programming</span>
                </Link>
                <Link
                  href="https://www.coursera.org/courses?query=communication"
                  target="_blank"
                  className="flex items-center gap-1 hover:underline"
                >
                  <div className="w-3 h-3 bg-pink-500 rounded-sm"></div>
                  <span className="text-xs">Communication</span>
                </Link>
                <Link
                  href="https://www.udemy.com/courses/design/"
                  target="_blank"
                  className="flex items-center gap-1 hover:underline"
                >
                  <div className="w-3 h-3 bg-cyan-500 rounded-sm"></div>
                  <span className="text-xs">Design</span>
                </Link>
                <Link
                  href="https://www.edx.org/learn/leadership"
                  target="_blank"
                  className="flex items-center gap-1 hover:underline"
                >
                  <div className="w-3 h-3 bg-purple-500 rounded-sm"></div>
                  <span className="text-xs">Leadership</span>
                </Link>
              </div>
            </div>
          </div>
        </div>

        <div className="mt-8">
          <h2 className="text-xl font-bold mb-4">Coursera Learning Paths</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Link
              href="https://www.coursera.org/professional-certificates/google-data-analytics"
              target="_blank"
              className="card hover:shadow-md transition-shadow"
            >
              <h3 className="font-semibold mb-2">Google Data Analytics</h3>
              <p className="text-sm text-muted-foreground mb-2">
                Learn in-demand skills like data cleaning, analysis, and visualization
              </p>
              <div className="text-xs text-muted-foreground">8 courses • Beginner level</div>
            </Link>

            <Link
              href="https://www.coursera.org/professional-certificates/meta-front-end-developer"
              target="_blank"
              className="card hover:shadow-md transition-shadow"
            >
              <h3 className="font-semibold mb-2">Meta Front-End Developer</h3>
              <p className="text-sm text-muted-foreground mb-2">
                Build job-ready skills for a career in front-end development
              </p>
              <div className="text-xs text-muted-foreground">9 courses • Beginner level</div>
            </Link>

            <Link
              href="https://www.coursera.org/professional-certificates/ibm-data-science"
              target="_blank"
              className="card hover:shadow-md transition-shadow"
            >
              <h3 className="font-semibold mb-2">IBM Data Science</h3>
              <p className="text-sm text-muted-foreground mb-2">
                Develop skills in Python, SQL, data visualization, and machine learning
              </p>
              <div className="text-xs text-muted-foreground">10 courses • Intermediate level</div>
            </Link>
          </div>
        </div>
      </div>
    </div>
  )
}
