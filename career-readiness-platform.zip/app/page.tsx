"use client"

import { useState } from "react"
import PageHeader from "@/components/page-header"
import { Button } from "@/components/ui/button"
import { Share2 } from "lucide-react"
import EducationLevelDialog from "@/components/education-level-dialog"
import StudyFieldDialog from "@/components/study-field-dialog"
import HobbiesDialog from "@/components/hobbies-dialog"
import CourseDialog from "@/components/course-dialog"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import CourseContent from "@/components/course-content"

export default function HomePage() {
  // State for selected values
  const [educationLevel, setEducationLevel] = useState<string | null>(null)
  const [currentStudy, setCurrentStudy] = useState<string | null>(null)
  const [futureField, setFutureField] = useState<string | null>(null)
  const [hobby, setHobby] = useState<string | null>(null)
  const [selectedTimeframe, setSelectedTimeframe] = useState("30-days")
  const [selectedCourse, setSelectedCourse] = useState<string | null>(null)
  const [showCourseContent, setShowCourseContent] = useState(false)

  // Sample course data
  const courseData = {
    "Google IT Support Professional Certificate": {
      title: "Google IT Support Professional Certificate",
      description: "Launch your career in IT with this comprehensive program",
      modules: [
        {
          title: "Technical Support Fundamentals",
          lessons: ["Introduction to IT", "Hardware Basics", "Operating Systems", "Networking Basics", "Software"],
          completed: true,
        },
        {
          title: "Computer Networking",
          lessons: ["TCP/IP", "Networking Devices", "Routing", "Network Services", "Troubleshooting"],
          completed: false,
        },
        {
          title: "Operating Systems",
          lessons: ["Windows", "Linux", "MacOS", "Mobile OS", "OS Security"],
          completed: false,
        },
      ],
    },
    "Meta Front-End Developer Professional Certificate": {
      title: "Meta Front-End Developer Professional Certificate",
      description: "Build job-ready skills for a career in front-end development",
      modules: [
        {
          title: "Introduction to Front-End Development",
          lessons: ["HTML Basics", "CSS Fundamentals", "Responsive Design", "JavaScript Intro", "Developer Tools"],
          completed: true,
        },
        {
          title: "Programming with JavaScript",
          lessons: ["Variables & Data Types", "Functions", "Arrays & Objects", "DOM Manipulation", "Events"],
          completed: false,
        },
        {
          title: "React Basics",
          lessons: ["Components", "Props & State", "Hooks", "Routing", "Forms in React"],
          completed: false,
        },
      ],
    },
    "Google Data Analytics Professional Certificate": {
      title: "Google Data Analytics Professional Certificate",
      description: "Get ready for a career in the high-growth field of data analytics",
      modules: [
        {
          title: "Foundations: Data, Data, Everywhere",
          lessons: [
            "Introduction to Data Analytics",
            "Thinking Analytically",
            "Data Types",
            "Data Ecosystem",
            "Career Paths",
          ],
          completed: false,
        },
        {
          title: "Ask Questions to Make Data-Driven Decisions",
          lessons: [
            "Problem Framing",
            "Data Collection Methods",
            "Spreadsheet Basics",
            "Data Cleaning",
            "Data Analysis",
          ],
          completed: false,
        },
        {
          title: "Prepare Data for Exploration",
          lessons: [
            "Data Types and Structures",
            "Bias in Data",
            "Organizing Data",
            "Data Formatting",
            "Data Transformation",
          ],
          completed: false,
        },
      ],
    },
  }

  const handleSelectCourse = (course: string) => {
    setSelectedCourse(course)
    setShowCourseContent(true)
  }

  return (
    <div className="flex flex-col min-h-screen">
      <PageHeader
        title="Learning Path"
        actions={
          <>
            <Button variant="outline" className="flex items-center gap-2">
              <Share2 className="h-4 w-4" />
              <span>Share Journey</span>
            </Button>
            <Dialog>
              <DialogTrigger>
                <Button className="flex items-center gap-2">
                  <span>Add New Skill</span>
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Add New Skill</DialogTitle>
                </DialogHeader>
                <div className="grid gap-4 py-4">
                  <Button variant="outline">Programming</Button>
                  <Button variant="outline">Communication</Button>
                  <Button variant="outline">Design</Button>
                  <Button variant="outline">Leadership</Button>
                  <Button variant="outline">Problem Solving</Button>
                </div>
              </DialogContent>
            </Dialog>
          </>
        }
      />

      <div className="p-6">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
          <EducationLevelDialog onSelect={setEducationLevel}>
            <div className="bg-blue-500 text-white rounded-lg p-6 h-full transition-transform hover:scale-105 cursor-pointer">
              <h2 className="text-2xl font-bold mb-2">School Level</h2>
              <p className="text-sm mb-4">{educationLevel || "Select your current education"}</p>
              <div className="w-full bg-blue-400 rounded-full h-2 mb-2">
                <div className="bg-white h-2 rounded-full" style={{ width: "60%" }}></div>
              </div>
            </div>
          </EducationLevelDialog>

          <StudyFieldDialog type="current" onSelect={setCurrentStudy}>
            <div className="bg-pink-500 text-white rounded-lg p-6 h-full transition-transform hover:scale-105 cursor-pointer">
              <h2 className="text-2xl font-bold mb-2">Current Study</h2>
              <p className="text-sm mb-4">{currentStudy || "Your field of study"}</p>
              <div className="w-full bg-pink-400 rounded-full h-2 mb-2">
                <div className="bg-white h-2 rounded-full" style={{ width: "70%" }}></div>
              </div>
            </div>
          </StudyFieldDialog>

          <StudyFieldDialog type="future" onSelect={setFutureField}>
            <div className="bg-cyan-500 text-white rounded-lg p-6 h-full transition-transform hover:scale-105 cursor-pointer">
              <h2 className="text-2xl font-bold mb-2">Future Field</h2>
              <p className="text-sm mb-4">{futureField || "Preferred area of study"}</p>
              <div className="w-full bg-cyan-400 rounded-full h-2 mb-2">
                <div className="bg-white h-2 rounded-full" style={{ width: "40%" }}></div>
              </div>
            </div>
          </StudyFieldDialog>

          <HobbiesDialog onSelect={setHobby}>
            <div className="bg-purple-500 text-white rounded-lg p-6 h-full transition-transform hover:scale-105 cursor-pointer">
              <h2 className="text-2xl font-bold mb-2">Hobbies</h2>
              <p className="text-sm mb-4">{hobby || "Your interests & activities"}</p>
              <div className="w-full bg-purple-400 rounded-full h-2 mb-2">
                <div className="bg-white h-2 rounded-full" style={{ width: "80%" }}></div>
              </div>
            </div>
          </HobbiesDialog>
        </div>

        <div className="grid md:grid-cols-2 gap-6">
          <div className="card">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-lg font-semibold">Skill Development Overview</h2>

              <div className="w-48">
                <select
                  className="select"
                  value={selectedTimeframe}
                  onChange={(e) => setSelectedTimeframe(e.target.value)}
                >
                  <option value="30-days">Last 30 Days</option>
                  <option value="3-months">Last 3 Months</option>
                  <option value="6-months">Last 6 Months</option>
                  <option value="1-year">Last Year</option>
                </select>
              </div>
            </div>

            <div className="text-center mb-4">
              <h3 className="text-sm font-medium text-muted-foreground">Skill Development Progress</h3>
            </div>

            <div className="h-64 w-full">
              <div className="relative h-full w-full">
                <svg viewBox="0 0 400 200" className="w-full h-full">
                  <g transform="translate(0,10)">
                    <g className="x-axis" transform="translate(0,160)">
                      <line x1="50" y1="0" x2="380" y2="0" stroke="#e2e8f0"></line>
                      <g transform="translate(50,0)">
                        <line y2="6" stroke="#e2e8f0"></line>
                        <text y="20" textAnchor="middle" fontSize="10" fill="#64748b">
                          Jan
                        </text>
                      </g>
                      <g transform="translate(105,0)">
                        <line y2="6" stroke="#e2e8f0"></line>
                        <text y="20" textAnchor="middle" fontSize="10" fill="#64748b">
                          Feb
                        </text>
                      </g>
                      <g transform="translate(160,0)">
                        <line y2="6" stroke="#e2e8f0"></line>
                        <text y="20" textAnchor="middle" fontSize="10" fill="#64748b">
                          Mar
                        </text>
                      </g>
                      <g transform="translate(215,0)">
                        <line y2="6" stroke="#e2e8f0"></line>
                        <text y="20" textAnchor="middle" fontSize="10" fill="#64748b">
                          Apr
                        </text>
                      </g>
                      <g transform="translate(270,0)">
                        <line y2="6" stroke="#e2e8f0"></line>
                        <text y="20" textAnchor="middle" fontSize="10" fill="#64748b">
                          May
                        </text>
                      </g>
                      <g transform="translate(325,0)">
                        <line y2="6" stroke="#e2e8f0"></line>
                        <text y="20" textAnchor="middle" fontSize="10" fill="#64748b">
                          Jun
                        </text>
                      </g>
                      <g transform="translate(380,0)">
                        <line y2="6" stroke="#e2e8f0"></line>
                        <text y="20" textAnchor="middle" fontSize="10" fill="#64748b">
                          Jul
                        </text>
                      </g>
                    </g>
                    <g className="y-axis">
                      <line x1="50" y1="0" x2="50" y2="160" stroke="#e2e8f0"></line>
                      <g transform="translate(0,160)">
                        <line x2="-6" stroke="#e2e8f0"></line>
                        <text x="-10" y="5" textAnchor="end" fontSize="10" fill="#64748b">
                          0
                        </text>
                      </g>
                      <g transform="translate(0,120)">
                        <line x2="-6" stroke="#e2e8f0"></line>
                        <text x="-10" y="5" textAnchor="end" fontSize="10" fill="#64748b">
                          20
                        </text>
                      </g>
                      <g transform="translate(0,80)">
                        <line x2="-6" stroke="#e2e8f0"></line>
                        <text x="-10" y="5" textAnchor="end" fontSize="10" fill="#64748b">
                          40
                        </text>
                      </g>
                      <g transform="translate(0,40)">
                        <line x2="-6" stroke="#e2e8f0"></line>
                        <text x="-10" y="5" textAnchor="end" fontSize="10" fill="#64748b">
                          60
                        </text>
                      </g>
                      <g transform="translate(0,0)">
                        <line x2="-6" stroke="#e2e8f0"></line>
                        <text x="-10" y="5" textAnchor="end" fontSize="10" fill="#64748b">
                          80
                        </text>
                      </g>
                    </g>

                    <path
                      d="M50,120 L105,100 L160,90 L215,70 L270,50 L325,40 L380,30"
                      fill="none"
                      stroke="#3b82f6"
                      strokeWidth="2"
                    ></path>
                    <path
                      d="M50,130 L105,110 L160,95 L215,80 L270,60 L325,45 L380,35"
                      fill="none"
                      stroke="#06b6d4"
                      strokeWidth="2"
                    ></path>

                    <circle cx="50" cy="120" r="3" fill="#3b82f6"></circle>
                    <circle cx="105" cy="100" r="3" fill="#3b82f6"></circle>
                    <circle cx="160" cy="90" r="3" fill="#3b82f6"></circle>
                    <circle cx="215" cy="70" r="3" fill="#3b82f6"></circle>
                    <circle cx="270" cy="50" r="3" fill="#3b82f6"></circle>
                    <circle cx="325" cy="40" r="3" fill="#3b82f6"></circle>
                    <circle cx="380" cy="30" r="3" fill="#3b82f6"></circle>

                    <circle cx="50" cy="130" r="3" fill="#06b6d4"></circle>
                    <circle cx="105" cy="110" r="3" fill="#06b6d4"></circle>
                    <circle cx="160" cy="95" r="3" fill="#06b6d4"></circle>
                    <circle cx="215" cy="80" r="3" fill="#06b6d4"></circle>
                    <circle cx="270" cy="60" r="3" fill="#06b6d4"></circle>
                    <circle cx="325" cy="45" r="3" fill="#06b6d4"></circle>
                    <circle cx="380" cy="35" r="3" fill="#06b6d4"></circle>
                  </g>
                </svg>
              </div>
            </div>

            <div className="flex justify-center mt-4">
              <div className="flex items-center gap-4">
                <CourseDialog
                  className="flex items-center gap-1 hover:underline cursor-pointer"
                  category="programming"
                  onSelect={() => {}}
                >
                  <div className="w-3 h-3 bg-blue-500 rounded-sm"></div>
                  <span className="text-xs">Technical Skills</span>
                </CourseDialog>
                <CourseDialog
                  className="flex items-center gap-1 hover:underline cursor-pointer"
                  category="communication"
                  onSelect={() => {}}
                >
                  <div className="w-3 h-3 bg-cyan-500 rounded-sm"></div>
                  <span className="text-xs">Soft Skills</span>
                </CourseDialog>
              </div>
            </div>
          </div>

          <div className="card">
            <h2 className="text-lg font-semibold mb-4">Skill Categories</h2>

            <div className="flex justify-center items-center h-64">
              <svg viewBox="0 0 200 200" className="w-64 h-64">
                <defs>
                  <mask id="donutMask">
                    <rect x="0" y="0" width="200" height="200" fill="white" />
                    <circle cx="100" cy="100" r="50" fill="black" />
                  </mask>
                </defs>

                <g mask="url(#donutMask)">
                  <path
                    d="M100,100 L100,0 A100,100 0 0,1 175,50 Z"
                    fill="#3b82f6"
                    className="cursor-pointer hover:opacity-80"
                  ></path>
                </g>
                <g mask="url(#donutMask)">
                  <path
                    d="M100,100 L175,50 A100,100 0 0,1 150,150 Z"
                    fill="#f43f5e"
                    className="cursor-pointer hover:opacity-80"
                  ></path>
                </g>
                <g mask="url(#donutMask)">
                  <path
                    d="M100,100 L150,150 A100,100 0 0,1 50,150 Z"
                    fill="#06b6d4"
                    className="cursor-pointer hover:opacity-80"
                  ></path>
                </g>
                <g mask="url(#donutMask)">
                  <path
                    d="M100,100 L50,150 A100,100 0 0,1 25,50 Z"
                    fill="#8b5cf6"
                    className="cursor-pointer hover:opacity-80"
                  ></path>
                </g>
                <g mask="url(#donutMask)">
                  <path
                    d="M100,100 L25,50 A100,100 0 0,1 100,0 Z"
                    fill="#3b82f6"
                    className="cursor-pointer hover:opacity-80"
                  ></path>
                </g>
              </svg>
            </div>

            <div className="flex justify-center mt-4">
              <div className="grid grid-cols-2 gap-x-8 gap-y-2">
                <Dialog>
                  <DialogTrigger>
                    <div className="flex items-center gap-1 hover:underline text-left">
                      <div className="w-3 h-3 bg-blue-500 rounded-sm"></div>
                      <span className="text-xs">Programming</span>
                    </div>
                  </DialogTrigger>
                  <DialogContent>
                    <DialogHeader>
                      <DialogTitle>Programming Skills</DialogTitle>
                    </DialogHeader>
                    <div className="space-y-4 py-4">
                      <p>Your programming skills are currently at an intermediate level.</p>
                      <div className="w-full bg-gray-200 rounded-full h-2.5">
                        <div className="bg-blue-500 h-2.5 rounded-full" style={{ width: "65%" }}></div>
                      </div>
                      <p className="text-sm text-muted-foreground">Recommended next steps:</p>
                      <ul className="list-disc pl-5 space-y-1 text-sm">
                        <li>Complete the JavaScript Fundamentals course</li>
                        <li>Practice data structures and algorithms</li>
                        <li>Build a portfolio project</li>
                      </ul>
                    </div>
                  </DialogContent>
                </Dialog>
                <Dialog>
                  <DialogTrigger>
                    <div className="flex items-center gap-1 hover:underline text-left">
                      <div className="w-3 h-3 bg-pink-500 rounded-sm"></div>
                      <span className="text-xs">Communication</span>
                    </div>
                  </DialogTrigger>
                  <DialogContent>
                    <DialogHeader>
                      <DialogTitle>Communication Skills</DialogTitle>
                    </DialogHeader>
                    <div className="space-y-4 py-4">
                      <p>Your communication skills are currently at a beginner level.</p>
                      <div className="w-full bg-gray-200 rounded-full h-2.5">
                        <div className="bg-pink-500 h-2.5 rounded-full" style={{ width: "35%" }}></div>
                      </div>
                      <p className="text-sm text-muted-foreground">Recommended next steps:</p>
                      <ul className="list-disc pl-5 space-y-1 text-sm">
                        <li>Take the Effective Communication course</li>
                        <li>Practice public speaking</li>
                        <li>Join a discussion group</li>
                      </ul>
                    </div>
                  </DialogContent>
                </Dialog>
                <Dialog>
                  <DialogTrigger>
                    <div className="flex items-center gap-1 hover:underline text-left">
                      <div className="w-3 h-3 bg-cyan-500 rounded-sm"></div>
                      <span className="text-xs">Design</span>
                    </div>
                  </DialogTrigger>
                  <DialogContent>
                    <DialogHeader>
                      <DialogTitle>Design Skills</DialogTitle>
                    </DialogHeader>
                    <div className="space-y-4 py-4">
                      <p>Your design skills are currently at a beginner level.</p>
                      <div className="w-full bg-gray-200 rounded-full h-2.5">
                        <div className="bg-cyan-500 h-2.5 rounded-full" style={{ width: "25%" }}></div>
                      </div>
                      <p className="text-sm text-muted-foreground">Recommended next steps:</p>
                      <ul className="list-disc pl-5 space-y-1 text-sm">
                        <li>Take the UI/UX Design Fundamentals course</li>
                        <li>Learn design principles</li>
                        <li>Practice with design tools</li>
                      </ul>
                    </div>
                  </DialogContent>
                </Dialog>
                <Dialog>
                  <DialogTrigger>
                    <div className="flex items-center gap-1 hover:underline text-left">
                      <div className="w-3 h-3 bg-purple-500 rounded-sm"></div>
                      <span className="text-xs">Leadership</span>
                    </div>
                  </DialogTrigger>
                  <DialogContent>
                    <DialogHeader>
                      <DialogTitle>Leadership Skills</DialogTitle>
                    </DialogHeader>
                    <div className="space-y-4 py-4">
                      <p>Your leadership skills are currently at a beginner level.</p>
                      <div className="w-full bg-gray-200 rounded-full h-2.5">
                        <div className="bg-purple-500 h-2.5 rounded-full" style={{ width: "30%" }}></div>
                      </div>
                      <p className="text-sm text-muted-foreground">Recommended next steps:</p>
                      <ul className="list-disc pl-5 space-y-1 text-sm">
                        <li>Take the Leadership Fundamentals course</li>
                        <li>Practice team management</li>
                        <li>Volunteer for leadership roles</li>
                      </ul>
                    </div>
                  </DialogContent>
                </Dialog>
              </div>
            </div>
          </div>
        </div>

        <div className="mt-8 grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="card">
            <h2 className="text-lg font-semibold mb-4">Recommended Learning Paths</h2>
            <div className="space-y-4">
              <Dialog>
                <DialogTrigger>
                  <button
                    className="block w-full text-left p-4 border rounded-lg hover:bg-muted transition-colors"
                    onClick={() => handleSelectCourse("Google IT Support Professional Certificate")}
                  >
                    <h3 className="font-medium">Google IT Support Professional Certificate</h3>
                    <p className="text-sm text-muted-foreground">
                      Launch your career in IT with this comprehensive program
                    </p>
                  </button>
                </DialogTrigger>
                <DialogContent className="sm:max-w-4xl">
                  <DialogHeader>
                    <DialogTitle>Course Details</DialogTitle>
                  </DialogHeader>
                  <div className="mt-4">
                    <CourseContent
                      title="Google IT Support Professional Certificate"
                      description="Launch your career in IT with this comprehensive program"
                      modules={courseData["Google IT Support Professional Certificate"].modules}
                    />
                  </div>
                </DialogContent>
              </Dialog>
              <Dialog>
                <DialogTrigger>
                  <button
                    className="block w-full text-left p-4 border rounded-lg hover:bg-muted transition-colors"
                    onClick={() => handleSelectCourse("Meta Front-End Developer Professional Certificate")}
                  >
                    <h3 className="font-medium">Meta Front-End Developer Professional Certificate</h3>
                    <p className="text-sm text-muted-foreground">
                      Build job-ready skills for a career in front-end development
                    </p>
                  </button>
                </DialogTrigger>
                <DialogContent className="sm:max-w-4xl">
                  <DialogHeader>
                    <DialogTitle>Course Details</DialogTitle>
                  </DialogHeader>
                  <div className="mt-4">
                    <CourseContent
                      title="Meta Front-End Developer Professional Certificate"
                      description="Build job-ready skills for a career in front-end development"
                      modules={courseData["Meta Front-End Developer Professional Certificate"].modules}
                    />
                  </div>
                </DialogContent>
              </Dialog>
              <Dialog>
                <DialogTrigger>
                  <button
                    className="block w-full text-left p-4 border rounded-lg hover:bg-muted transition-colors"
                    onClick={() => handleSelectCourse("Google Data Analytics Professional Certificate")}
                  >
                    <h3 className="font-medium">Google Data Analytics Professional Certificate</h3>
                    <p className="text-sm text-muted-foreground">
                      Get ready for a career in the high-growth field of data analytics
                    </p>
                  </button>
                </DialogTrigger>
                <DialogContent className="sm:max-w-4xl">
                  <DialogHeader>
                    <DialogTitle>Course Details</DialogTitle>
                  </DialogHeader>
                  <div className="mt-4">
                    <CourseContent
                      title="Google Data Analytics Professional Certificate"
                      description="Get ready for a career in the high-growth field of data analytics"
                      modules={courseData["Google Data Analytics Professional Certificate"].modules}
                    />
                  </div>
                </DialogContent>
              </Dialog>
            </div>
          </div>

          <div className="card">
            <h2 className="text-lg font-semibold mb-4">Popular Free Resources</h2>
            <div className="space-y-4">
              <Dialog>
                <DialogTrigger>
                  <button className="block w-full text-left p-4 border rounded-lg hover:bg-muted transition-colors">
                    <h3 className="font-medium">freeCodeCamp</h3>
                    <p className="text-sm text-muted-foreground">
                      Learn to code with free interactive lessons and earn certifications
                    </p>
                  </button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>freeCodeCamp</DialogTitle>
                  </DialogHeader>
                  <div className="space-y-4 py-4">
                    <p>freeCodeCamp offers free coding courses covering:</p>
                    <ul className="list-disc pl-5 space-y-1">
                      <li>Responsive Web Design</li>
                      <li>JavaScript Algorithms and Data Structures</li>
                      <li>Front End Development Libraries</li>
                      <li>Data Visualization</li>
                      <li>Back End Development and APIs</li>
                      <li>Quality Assurance</li>
                      <li>Scientific Computing with Python</li>
                      <li>Data Analysis with Python</li>
                      <li>Information Security</li>
                      <li>Machine Learning with Python</li>
                    </ul>
                    <Button className="w-full">Start Learning</Button>
                  </div>
                </DialogContent>
              </Dialog>
              <Dialog>
                <DialogTrigger>
                  <button className="block w-full text-left p-4 border rounded-lg hover:bg-muted transition-colors">
                    <h3 className="font-medium">Khan Academy</h3>
                    <p className="text-sm text-muted-foreground">Free world-class education for anyone, anywhere</p>
                  </button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>Khan Academy</DialogTitle>
                  </DialogHeader>
                  <div className="space-y-4 py-4">
                    <p>Khan Academy offers free courses in:</p>
                    <ul className="list-disc pl-5 space-y-1">
                      <li>Math (from basic to advanced)</li>
                      <li>Science & Engineering</li>
                      <li>Computing</li>
                      <li>Arts & Humanities</li>
                      <li>Economics & Finance</li>
                      <li>Test Preparation</li>
                    </ul>
                    <Button className="w-full">Start Learning</Button>
                  </div>
                </DialogContent>
              </Dialog>
              <Dialog>
                <DialogTrigger>
                  <button className="block w-full text-left p-4 border rounded-lg hover:bg-muted transition-colors">
                    <h3 className="font-medium">edX Free Courses</h3>
                    <p className="text-sm text-muted-foreground">
                      Access university-level courses from top institutions
                    </p>
                  </button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>edX Free Courses</DialogTitle>
                  </DialogHeader>
                  <div className="space-y-4 py-4">
                    <p>edX offers free courses from universities like Harvard, MIT, and more in:</p>
                    <ul className="list-disc pl-5 space-y-1">
                      <li>Computer Science</li>
                      <li>Business & Management</li>
                      <li>Engineering</li>
                      <li>Humanities</li>
                      <li>Data Science</li>
                      <li>Language</li>
                      <li>Science</li>
                    </ul>
                    <Button className="w-full">Browse Courses</Button>
                  </div>
                </DialogContent>
              </Dialog>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
