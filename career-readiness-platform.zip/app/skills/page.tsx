"use client"

import { useRouter } from "next/navigation"
import PageHeader from "@/components/page-header"
import { Button } from "@/components/ui/button"
import { Code, MessageSquare, Star, RefreshCw, Info } from "lucide-react"

export default function SkillsPage() {
  const router = useRouter()

  return (
    <div className="flex flex-col min-h-screen">
      <PageHeader
        title="Skills Assessment"
        actions={
          <>
            <Button variant="outline" className="flex items-center gap-2" onClick={() => router.push("/skills/export")}>
              <span>Export Results</span>
            </Button>
            <Button className="flex items-center gap-2" onClick={() => router.push("/skills/assessment/start")}>
              <span>Take Assessment</span>
            </Button>
          </>
        }
      />

      <div className="grid md:grid-cols-2 gap-6 p-6">
        <div className="card">
          <h2 className="text-lg font-semibold mb-4">Your Skill Profile</h2>

          <div className="space-y-6">
            <div>
              <h3 className="font-medium mb-2">Technical Skills</h3>
              <button
                onClick={() => router.push("/skills/category/programming")}
                className="flex items-center border rounded-md overflow-hidden hover:bg-muted transition-colors w-full"
              >
                <div className="flex items-center justify-center w-12 h-12 bg-gray-100">
                  <Code className="h-5 w-5" />
                </div>
                <div className="px-4 py-2 flex-1 text-left">
                  <span>Programming</span>
                </div>
              </button>
            </div>

            <div>
              <h3 className="font-medium mb-2">Soft Skills</h3>
              <button
                onClick={() => router.push("/skills/category/communication")}
                className="flex items-center border rounded-md overflow-hidden hover:bg-muted transition-colors w-full"
              >
                <div className="flex items-center justify-center w-12 h-12 bg-gray-100">
                  <MessageSquare className="h-5 w-5" />
                </div>
                <div className="px-4 py-2 flex-1 text-left">
                  <span>Communication</span>
                </div>
              </button>
            </div>

            <div>
              <h3 className="font-medium mb-2">Areas of Interest</h3>
              <button
                onClick={() => router.push("/skills/interest/software-development")}
                className="flex items-center border rounded-md overflow-hidden hover:bg-muted transition-colors w-full"
              >
                <div className="flex items-center justify-center w-12 h-12 bg-gray-100">
                  <Star className="h-5 w-5" />
                </div>
                <div className="px-4 py-2 flex-1 text-left">
                  <span>Software Development</span>
                </div>
              </button>
            </div>

            <Button
              className="w-full flex items-center justify-center gap-2"
              onClick={() => router.push("/skills/profile/update")}
            >
              <RefreshCw className="h-4 w-4" />
              <span>Update Skill Profile</span>
            </Button>

            <div className="flex items-center justify-between pt-2 border-t">
              <span className="text-sm font-medium">Profile Completeness:</span>
              <span className="text-sm font-medium">75%</span>
            </div>
            <div className="w-full bg-gray-200 rounded-full h-2.5">
              <div className="bg-primary h-2.5 rounded-full" style={{ width: "75%" }}></div>
            </div>
          </div>
        </div>

        <div className="card">
          <h2 className="text-lg font-semibold mb-4">Interactive Assessment</h2>

          <div className="space-y-6">
            <div>
              <h3 className="font-medium mb-2">Technical Proficiency</h3>

              <div className="space-y-4">
                <div>
                  <div className="flex justify-between mb-1">
                    <span className="text-sm">Coding & Programming</span>
                  </div>
                  <button
                    onClick={() => router.push("/skills/assessment/coding")}
                    className="flex items-center border rounded-md overflow-hidden hover:bg-muted transition-colors w-full"
                  >
                    <div className="flex items-center justify-center w-12 h-12 bg-gray-100">
                      <Code className="h-5 w-5" />
                    </div>
                    <div className="px-4 py-2 flex-1 text-left">
                      <span>Beginner</span>
                    </div>
                    <div className="flex items-center justify-center w-12 h-12">
                      <Info className="h-5 w-5 text-gray-400" />
                    </div>
                  </button>
                </div>

                <div>
                  <div className="flex justify-between mb-1">
                    <span className="text-sm">Data Analysis</span>
                  </div>
                  <button
                    onClick={() => router.push("/skills/assessment/data-analysis")}
                    className="flex items-center border rounded-md overflow-hidden hover:bg-muted transition-colors w-full"
                  >
                    <div className="flex items-center justify-center w-12 h-12 bg-gray-100">
                      <svg className="h-5 w-5" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path
                          d="M8 13V17M12 9V17M16 5V17M5 21H19C20.1046 21 21 20.1046 21 19V5C21 3.89543 20.1046 3 19 3H5C3.89543 3 3 3.89543 3 5V19C3 20.1046 3.89543 21 5 21Z"
                          stroke="currentColor"
                          strokeWidth="2"
                          strokeLinecap="round"
                          strokeLinejoin="round"
                        />
                      </svg>
                    </div>
                    <div className="px-4 py-2 flex-1 text-left">
                      <span>Beginner</span>
                    </div>
                    <div className="flex items-center justify-center w-12 h-12">
                      <Info className="h-5 w-5 text-gray-400" />
                    </div>
                  </button>
                </div>
              </div>
            </div>

            <div>
              <h3 className="font-medium mb-2">Soft Skills</h3>

              <div className="space-y-4">
                <div>
                  <div className="flex justify-between mb-1">
                    <span className="text-sm">Communication</span>
                  </div>
                  <button
                    onClick={() => router.push("/skills/assessment/communication")}
                    className="flex items-center border rounded-md overflow-hidden hover:bg-muted transition-colors w-full"
                  >
                    <div className="flex items-center justify-center w-12 h-12 bg-gray-100">
                      <MessageSquare className="h-5 w-5" />
                    </div>
                    <div className="px-4 py-2 flex-1 text-left">
                      <span>Beginner</span>
                    </div>
                    <div className="flex items-center justify-center w-12 h-12">
                      <Info className="h-5 w-5 text-gray-400" />
                    </div>
                  </button>
                </div>

                <div>
                  <div className="flex justify-between mb-1">
                    <span className="text-sm">Teamwork & Collaboration</span>
                  </div>
                  <button
                    onClick={() => router.push("/skills/assessment/teamwork")}
                    className="flex items-center border rounded-md overflow-hidden hover:bg-muted transition-colors w-full"
                  >
                    <div className="flex items-center justify-center w-12 h-12 bg-gray-100">
                      <svg className="h-5 w-5" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path
                          d="M17 20H22V18C22 16.3431 20.6569 15 19 15C18.0444 15 17.1931 15.4468 16.6438 16.1429M17 20H7M17 20V18C17 17.3438 16.8736 16.717 16.6438 16.1429M7 20H2V18C2 16.3431 3.34315 15 5 15C5.95561 15 6.80686 15.4468 7.35625 16.1429M7 20V18C7 17.3438 7.12642 16.717 7.35625 16.1429M7.35625 16.1429C8.0935 14.301 9.89482 13 12 13C14.1052 13 15.9065 14.301 16.6438 16.1429M15 7C15 8.65685 13.6569 10 12 10C10.3431 10 9 8.65685 9 7C9 5.34315 10.3431 4 12 4C13.6569 4 15 5.34315 15 7ZM21 10C21 11.1046 20.1046 12 19 12C17.8954 12 17 11.1046 17 10C17 8.89543 17.8954 8 19 8C20.1046 8 21 8.89543 21 10ZM7 10C7 11.1046 6.10457 12 5 12C3.89543 12 3 11.1046 3 10C3 8.89543 3.89543 8 5 8C6.10457 8 7 8.89543 7 10Z"
                          stroke="currentColor"
                          strokeWidth="2"
                          strokeLinecap="round"
                          strokeLinejoin="round"
                        />
                      </svg>
                    </div>
                    <div className="px-4 py-2 flex-1 text-left">
                      <span>Beginner</span>
                    </div>
                    <div className="flex items-center justify-center w-12 h-12">
                      <Info className="h-5 w-5 text-gray-400" />
                    </div>
                  </button>
                </div>
              </div>
            </div>

            <div>
              <h3 className="font-medium mb-2">Learning Preferences</h3>

              <div className="space-y-4">
                <div>
                  <div className="flex justify-between mb-1">
                    <span className="text-sm">Learning Style</span>
                  </div>
                  <button
                    onClick={() => router.push("/skills/learning-style")}
                    className="flex items-center border rounded-md overflow-hidden hover:bg-muted transition-colors w-full"
                  >
                    <div className="flex items-center justify-center w-12 h-12 bg-gray-100">
                      <svg className="h-5 w-5" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path
                          d="M2 12C2 17.5228 6.47715 22 12 22C17.5228 22 22 17.5228 22 12C22 6.47715 17.5228 2 12 2C6.47715 2 2 6.47715 2 12Z"
                          stroke="currentColor"
                          strokeWidth="2"
                          strokeLinecap="round"
                          strokeLinejoin="round"
                        />
                        <path
                          d="M12 17V17.01M12 14C12.5523 14 13 13.5523 13 13C13 12.4477 12.5523 12 12 12C11.4477 12 11 12.4477 11 13C11 13.5523 11.4477 14 12 14ZM12 14V10"
                          stroke="currentColor"
                          strokeWidth="2"
                          strokeLinecap="round"
                        />
                      </svg>
                    </div>
                    <div className="px-4 py-2 flex-1 text-left">
                      <span>Visual</span>
                    </div>
                    <div className="flex items-center justify-center w-12 h-12">
                      <Info className="h-5 w-5 text-gray-400" />
                    </div>
                  </button>
                </div>

                <div>
                  <div className="flex justify-between mb-1">
                    <span className="text-sm">Preferred Pace</span>
                  </div>
                  <button
                    onClick={() => router.push("/skills/learning-pace")}
                    className="flex items-center border rounded-md overflow-hidden hover:bg-muted transition-colors w-full"
                  >
                    <div className="flex items-center justify-center w-12 h-12 bg-gray-100">
                      <svg className="h-5 w-5" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path
                          d="M12 8V12L15 15M21 12C21 16.9706 16.9706 21 12 21C7.02944 21 3 16.9706 3 12C3 7.02944 7.02944 3 12 3C16.9706 3 21 7.02944 21 12Z"
                          stroke="currentColor"
                          strokeWidth="2"
                          strokeLinecap="round"
                          strokeLinejoin="round"
                        />
                      </svg>
                    </div>
                    <div className="px-4 py-2 flex-1 text-left">
                      <span>Self-paced</span>
                    </div>
                    <div className="flex items-center justify-center w-12 h-12">
                      <Info className="h-5 w-5 text-gray-400" />
                    </div>
                  </button>
                </div>
              </div>
            </div>

            <Button className="w-full" onClick={() => router.push("/skills/assessment/full")}>
              Take Full Assessment
            </Button>
          </div>
        </div>
      </div>
    </div>
  )
}
