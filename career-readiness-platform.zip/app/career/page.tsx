"use client"

import { useRouter } from "next/navigation"
import PageHeader from "@/components/page-header"
import { Button } from "@/components/ui/button"
import { Eye, BookOpen, Award } from "lucide-react"

export default function CareerPage() {
  const router = useRouter()

  return (
    <div className="flex flex-col min-h-screen">
      <PageHeader
        title="Career Path"
        actions={
          <>
            <Button
              variant="outline"
              className="flex items-center gap-2"
              onClick={() => router.push("/career/readiness-score")}
            >
              <span>Career Readiness Score</span>
            </Button>
            <Button className="flex items-center gap-2" onClick={() => router.push("/career/explore")}>
              <span>Explore New Paths</span>
            </Button>
          </>
        }
      />

      <div className="grid md:grid-cols-3 gap-6 p-6">
        <div className="md:col-span-2">
          <div className="card">
            <h2 className="text-lg font-semibold mb-6">Recommended Career Paths</h2>

            <div className="space-y-8">
              <div>
                <div className="flex justify-between items-center mb-2">
                  <h3 className="text-xl font-semibold">Software Development Engineer</h3>
                  <span className="inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-semibold bg-blue-500 text-white">
                    85% Match
                  </span>
                </div>

                <div className="flex justify-between items-center mb-2">
                  <div className="text-sm">Skills Match: 12 of 15 key skills</div>
                  <div className="text-sm">High Demand Field</div>
                </div>

                <div className="w-full bg-gray-200 rounded-full h-2 mb-4">
                  <div className="bg-blue-500 h-2 rounded-full" style={{ width: "80%" }}></div>
                </div>

                <div className="flex justify-between items-center mb-4 text-sm">
                  <div>Entry Level</div>
                  <div>Junior</div>
                  <div>Mid-Level</div>
                  <div>Senior</div>
                </div>

                <div className="flex justify-between items-center mb-4">
                  <div className="flex items-center gap-2">
                    <Award className="h-4 w-4" />
                    <button
                      onClick={() => router.push("/certifications/aws-cloud-practitioner")}
                      className="text-sm hover:underline"
                    >
                      Recommended: AWS Certification
                    </button>
                  </div>

                  <div className="flex items-center gap-2">
                    <svg className="h-4 w-4" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                      <path
                        d="M12 6V12L16 14M22 12C22 17.5228 17.5228 22 12 22C6.47715 22 2 17.5228 2 12C2 6.47715 6.47715 2 12 2C17.5228 2 22 6.47715 22 12Z"
                        stroke="currentColor"
                        strokeWidth="2"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                      />
                    </svg>
                    <button
                      onClick={() => router.push("/career/salary/software-development-engineer")}
                      className="text-sm hover:underline"
                    >
                      Avg. Salary: $95,000
                    </button>
                  </div>
                </div>

                <div className="flex gap-2">
                  <Button
                    variant="outline"
                    size="sm"
                    className="flex items-center gap-1"
                    onClick={() => router.push("/career/details/software-development-engineer")}
                  >
                    <Eye className="h-4 w-4" />
                    <span>View Details</span>
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    className="flex items-center gap-1"
                    onClick={() => router.push("/courses/software-development")}
                  >
                    <BookOpen className="h-4 w-4" />
                    <span>View Relevant Courses</span>
                  </Button>
                </div>
              </div>

              <div>
                <div className="flex justify-between items-center mb-2">
                  <h3 className="text-xl font-semibold">UX/UI Designer</h3>
                  <span className="inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-semibold bg-green-500 text-white">
                    87% Match
                  </span>
                </div>

                <div className="flex justify-between items-center mb-2">
                  <div className="text-sm">Skills Match: 10 of 12 key skills</div>
                  <div className="text-sm">Growing Field</div>
                </div>

                <div className="w-full bg-gray-200 rounded-full h-2 mb-4">
                  <div className="bg-green-500 h-2 rounded-full" style={{ width: "70%" }}></div>
                </div>

                <div className="flex justify-between items-center mb-4 text-sm">
                  <div>Beginner</div>
                  <div>Foundation</div>
                  <div>Intermediate</div>
                  <div>Advanced</div>
                </div>

                <div className="flex justify-between items-center mb-4">
                  <div className="flex items-center gap-2">
                    <Award className="h-4 w-4" />
                    <button
                      onClick={() => router.push("/certifications/ux-design")}
                      className="text-sm hover:underline"
                    >
                      Recommended: UI/UX Certification
                    </button>
                  </div>

                  <div className="flex items-center gap-2">
                    <svg className="h-4 w-4" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                      <path
                        d="M12 6V12L16 14M22 12C22 17.5228 17.5228 22 12 22C6.47715 22 2 17.5228 2 12C2 6.47715 6.47715 2 12 2C17.5228 2 22 6.47715 22 12Z"
                        stroke="currentColor"
                        strokeWidth="2"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                      />
                    </svg>
                    <button
                      onClick={() => router.push("/career/salary/ux-ui-designer")}
                      className="text-sm hover:underline"
                    >
                      Avg. Salary: $85,000
                    </button>
                  </div>
                </div>

                <div className="flex gap-2">
                  <Button
                    variant="outline"
                    size="sm"
                    className="flex items-center gap-1"
                    onClick={() => router.push("/career/details/ux-ui-designer")}
                  >
                    <Eye className="h-4 w-4" />
                    <span>View Details</span>
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    className="flex items-center gap-1"
                    onClick={() => router.push("/courses/ux-design")}
                  >
                    <BookOpen className="h-4 w-4" />
                    <span>View Relevant Courses</span>
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="space-y-6">
          <div className="card">
            <h2 className="text-lg font-semibold mb-4">Skill Gap Analysis</h2>

            <div className="h-64 w-full">
              <div className="relative h-full w-full">
                <div className="flex h-full">
                  <div className="flex flex-col justify-end items-center w-1/4 h-full px-1">
                    <div className="flex w-full">
                      <div className="w-1/2 bg-blue-500 h-[70px]"></div>
                      <div className="w-1/2 bg-pink-500 h-[85px]"></div>
                    </div>
                    <button
                      onClick={() => router.push("/skills/category/technical")}
                      className="text-xs mt-2 text-center hover:underline"
                    >
                      Technical
                    </button>
                  </div>
                  <div className="flex flex-col justify-end items-center w-1/4 h-full px-1">
                    <div className="flex w-full">
                      <div className="w-1/2 bg-blue-500 h-[80px]"></div>
                      <div className="w-1/2 bg-pink-500 h-[75px]"></div>
                    </div>
                    <button
                      onClick={() => router.push("/skills/category/communication")}
                      className="text-xs mt-2 text-center hover:underline"
                    >
                      Communication
                    </button>
                  </div>
                  <div className="flex flex-col justify-end items-center w-1/4 h-full px-1">
                    <div className="flex w-full">
                      <div className="w-1/2 bg-blue-500 h-[60px]"></div>
                      <div className="w-1/2 bg-pink-500 h-[80px]"></div>
                    </div>
                    <button
                      onClick={() => router.push("/skills/category/leadership")}
                      className="text-xs mt-2 text-center hover:underline"
                    >
                      Leadership
                    </button>
                  </div>
                  <div className="flex flex-col justify-end items-center w-1/4 h-full px-1">
                    <div className="flex w-full">
                      <div className="w-1/2 bg-blue-500 h-[85px]"></div>
                      <div className="w-1/2 bg-pink-500 h-[80px]"></div>
                    </div>
                    <button
                      onClick={() => router.push("/skills/category/problem-solving")}
                      className="text-xs mt-2 text-center hover:underline"
                    >
                      Problem Solving
                    </button>
                  </div>
                </div>
                <div className="absolute left-0 top-0 h-full border-l border-gray-200"></div>
                <div className="absolute bottom-0 left-0 w-full border-b border-gray-200"></div>
              </div>
            </div>

            <div className="flex justify-center mt-4">
              <div className="flex items-center gap-4">
                <div className="flex items-center gap-1">
                  <div className="w-3 h-3 bg-blue-500 rounded-sm"></div>
                  <span className="text-xs">Your Skills</span>
                </div>
                <div className="flex items-center gap-1">
                  <div className="w-3 h-3 bg-pink-500 rounded-sm"></div>
                  <span className="text-xs">Required for Career</span>
                </div>
              </div>
            </div>
          </div>

          <div className="card">
            <h2 className="text-lg font-semibold mb-4">Recommended Certifications</h2>
            <div className="space-y-4">
              <button
                onClick={() => router.push("/certifications/aws-cloud-practitioner")}
                className="block p-3 border rounded-lg hover:bg-muted transition-colors w-full text-left"
              >
                <h3 className="font-medium">AWS Certified Cloud Practitioner</h3>
                <p className="text-xs text-muted-foreground">Foundational • 6 months experience</p>
              </button>
              <button
                onClick={() => router.push("/certifications/google-ux-design")}
                className="block p-3 border rounded-lg hover:bg-muted transition-colors w-full text-left"
              >
                <h3 className="font-medium">Google UX Design Professional Certificate</h3>
                <p className="text-xs text-muted-foreground">Beginner • No experience required</p>
              </button>
              <button
                onClick={() => router.push("/certifications/google-project-management")}
                className="block p-3 border rounded-lg hover:bg-muted transition-colors w-full text-left"
              >
                <h3 className="font-medium">Google Project Management Certificate</h3>
                <p className="text-xs text-muted-foreground">Beginner • No experience required</p>
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
