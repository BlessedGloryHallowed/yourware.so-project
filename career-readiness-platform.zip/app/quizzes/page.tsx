"use client"

import { useState } from "react"
import PageHeader from "@/components/page-header"
import { Button } from "@/components/ui/button"
import { Code, MessageSquare, FileText, Target } from "lucide-react"
import QuizDialog from "@/components/quiz-dialog"
import QuizContent from "@/components/quiz-content"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"

export default function QuizzesPage() {
  const [selectedCategory, setSelectedCategory] = useState("all")
  const [selectedQuiz, setSelectedQuiz] = useState<string | null>(null)
  const [showQuizContent, setShowQuizContent] = useState(false)

  // Sample quiz data
  const quizData = {
    "Programming Fundamentals": {
      title: "Programming Fundamentals",
      description: "Test your knowledge of basic programming concepts",
      questions: [
        {
          question: "What is a variable?",
          options: [
            "A container for storing data values",
            "A mathematical operation",
            "A type of function",
            "A programming language",
          ],
          correctAnswer: 0,
        },
        {
          question: "Which of the following is NOT a programming language?",
          options: ["Java", "Python", "HTML", "C++"],
          correctAnswer: 2,
        },
        {
          question: "What does the acronym 'API' stand for?",
          options: [
            "Application Programming Interface",
            "Automated Program Integration",
            "Advanced Programming Implementation",
            "Application Process Integration",
          ],
          correctAnswer: 0,
        },
      ],
    },
    "Effective Communication": {
      title: "Effective Communication",
      description: "Test your knowledge of communication skills",
      questions: [
        {
          question: "What is active listening?",
          options: [
            "Interrupting to show engagement",
            "Fully concentrating on the speaker",
            "Thinking about your response while someone is speaking",
            "Speaking loudly and clearly",
          ],
          correctAnswer: 1,
        },
        {
          question: "Which of the following is NOT a component of nonverbal communication?",
          options: ["Body language", "Facial expressions", "Written text", "Eye contact"],
          correctAnswer: 2,
        },
        {
          question: "What is the purpose of constructive feedback?",
          options: [
            "To criticize someone's work",
            "To help someone improve",
            "To demonstrate your expertise",
            "To avoid conflict",
          ],
          correctAnswer: 1,
        },
      ],
    },
  }

  const handleSelectQuiz = (quiz: string) => {
    setSelectedQuiz(quiz)
    setShowQuizContent(true)
  }

  return (
    <div className="flex flex-col min-h-screen">
      <PageHeader
        title="Knowledge Quizzes"
        actions={
          <>
            <Dialog>
              <DialogTrigger>
                <Button variant="outline" className="flex items-center gap-2">
                  <span>Filter Topics</span>
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Filter Quiz Topics</DialogTitle>
                </DialogHeader>
                <div className="grid gap-4 py-4">
                  <Button variant="outline" onClick={() => setSelectedCategory("all")}>
                    All Categories
                  </Button>
                  <Button variant="outline" onClick={() => setSelectedCategory("technical")}>
                    Technical
                  </Button>
                  <Button variant="outline" onClick={() => setSelectedCategory("soft-skills")}>
                    Soft Skills
                  </Button>
                  <Button variant="outline" onClick={() => setSelectedCategory("career")}>
                    Career
                  </Button>
                </div>
              </DialogContent>
            </Dialog>
            <QuizDialog onSelect={handleSelectQuiz}>
              <Button className="flex items-center gap-2">
                <span>Start New Quiz</span>
              </Button>
            </QuizDialog>
          </>
        }
      />

      <div className="grid md:grid-cols-3 gap-6 p-6">
        <div className="md:col-span-2">
          <div className="card">
            <h2 className="text-lg font-semibold mb-4">Available Quizzes</h2>

            <div className="flex justify-end mb-4">
              <div className="w-48">
                <select
                  className="select"
                  value={selectedCategory}
                  onChange={(e) => setSelectedCategory(e.target.value)}
                >
                  <option value="all">All Categories</option>
                  <option value="technical">Technical</option>
                  <option value="soft-skills">Soft Skills</option>
                  <option value="career">Career</option>
                </select>
              </div>
            </div>

            <div className="space-y-4">
              <div className="border-b pb-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center">
                    <div className="flex items-center justify-center w-10 h-10 rounded-full bg-blue-500 text-white mr-4">
                      <Code className="h-5 w-5" />
                    </div>
                    <div>
                      <h3 className="font-semibold">Programming Fundamentals</h3>
                      <p className="text-sm text-muted-foreground">15 questions • Beginner</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-4">
                    <span className="tag tag-blue">10 points</span>
                    <Dialog>
                      <DialogTrigger>
                        <Button variant="outline" size="sm">
                          Start Quiz
                        </Button>
                      </DialogTrigger>
                      <DialogContent className="sm:max-w-4xl">
                        <DialogHeader>
                          <DialogTitle>Quiz</DialogTitle>
                        </DialogHeader>
                        <div className="mt-4">
                          <QuizContent
                            title="Programming Fundamentals"
                            description="Test your knowledge of basic programming concepts"
                            questions={quizData["Programming Fundamentals"].questions}
                          />
                        </div>
                      </DialogContent>
                    </Dialog>
                  </div>
                </div>
              </div>

              <div className="border-b pb-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center">
                    <div className="flex items-center justify-center w-10 h-10 rounded-full bg-cyan-500 text-white mr-4">
                      <MessageSquare className="h-5 w-5" />
                    </div>
                    <div>
                      <h3 className="font-semibold">Effective Communication</h3>
                      <p className="text-sm text-muted-foreground">12 questions • Intermediate</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-4">
                    <span className="tag tag-cyan">15 points</span>
                    <Dialog>
                      <DialogTrigger>
                        <Button variant="outline" size="sm">
                          Start Quiz
                        </Button>
                      </DialogTrigger>
                      <DialogContent className="sm:max-w-4xl">
                        <DialogHeader>
                          <DialogTitle>Quiz</DialogTitle>
                        </DialogHeader>
                        <div className="mt-4">
                          <QuizContent
                            title="Effective Communication"
                            description="Test your knowledge of communication skills"
                            questions={quizData["Effective Communication"].questions}
                          />
                        </div>
                      </DialogContent>
                    </Dialog>
                  </div>
                </div>
              </div>

              <div className="border-b pb-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center">
                    <div className="flex items-center justify-center w-10 h-10 rounded-full bg-yellow-500 text-white mr-4">
                      <FileText className="h-5 w-5" />
                    </div>
                    <div>
                      <h3 className="font-semibold">Resume Building & Interviews</h3>
                      <p className="text-sm text-muted-foreground">20 questions • All levels</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-4">
                    <span className="tag tag-green">20 points</span>
                    <Dialog>
                      <DialogTrigger>
                        <Button variant="outline" size="sm">
                          Start Quiz
                        </Button>
                      </DialogTrigger>
                      <DialogContent className="sm:max-w-4xl">
                        <DialogHeader>
                          <DialogTitle>Quiz</DialogTitle>
                        </DialogHeader>
                        <div className="mt-4">
                          <QuizContent
                            title="Resume Building & Interviews"
                            description="Test your knowledge of resume building and interview skills"
                            questions={[
                              {
                                question: "What should you always include in your resume?",
                                options: [
                                  "Your photo",
                                  "Your contact information",
                                  "Your marital status",
                                  "Your salary expectations",
                                ],
                                correctAnswer: 1,
                              },
                              {
                                question: "What is the STAR method used for?",
                                options: [
                                  "Rating job candidates",
                                  "Structuring your resume",
                                  "Answering behavioral interview questions",
                                  "Evaluating job offers",
                                ],
                                correctAnswer: 2,
                              },
                              {
                                question: "What should you do at the end of an interview?",
                                options: [
                                  "Ask about salary immediately",
                                  "Leave quickly to show you respect their time",
                                  "Ask thoughtful questions about the role and company",
                                  "Tell them you'll think about it if they offer you the job",
                                ],
                                correctAnswer: 2,
                              },
                            ]}
                          />
                        </div>
                      </DialogContent>
                    </Dialog>
                  </div>
                </div>
              </div>

              <div className="border-b pb-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center">
                    <div className="flex items-center justify-center w-10 h-10 rounded-full bg-red-500 text-white mr-4">
                      <Target className="h-5 w-5" />
                    </div>
                    <div>
                      <h3 className="font-semibold">Project Management</h3>
                      <p className="text-sm text-muted-foreground">18 questions • Advanced</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-4">
                    <span className="tag tag-yellow">25 points</span>
                    <Dialog>
                      <DialogTrigger>
                        <Button variant="outline" size="sm">
                          Start Quiz
                        </Button>
                      </DialogTrigger>
                      <DialogContent className="sm:max-w-4xl">
                        <DialogHeader>
                          <DialogTitle>Quiz</DialogTitle>
                        </DialogHeader>
                        <div className="mt-4">
                          <QuizContent
                            title="Project Management"
                            description="Test your knowledge of project management principles"
                            questions={[
                              {
                                question: "What is a Gantt chart used for?",
                                options: [
                                  "Budget tracking",
                                  "Resource allocation",
                                  "Project scheduling and timeline visualization",
                                  "Risk assessment",
                                ],
                                correctAnswer: 2,
                              },
                              {
                                question: "What does the acronym 'WBS' stand for in project management?",
                                options: [
                                  "Work Breakdown Structure",
                                  "Weekly Budget Summary",
                                  "Workflow Business System",
                                  "Work Balance Sheet",
                                ],
                                correctAnswer: 0,
                              },
                              {
                                question:
                                  "Which project management methodology is characterized by iterative development and frequent delivery?",
                                options: ["Waterfall", "Agile", "Critical Path Method", "PRINCE2"],
                                correctAnswer: 1,
                              },
                            ]}
                          />
                        </div>
                      </DialogContent>
                    </Dialog>
                  </div>
                </div>
              </div>
            </div>

            <div className="flex justify-center mt-6">
              <div className="flex">
                <Button variant="outline" size="sm" className="rounded-r-none">
                  Previous
                </Button>
                <Button variant="default" size="sm" className="rounded-none">
                  1
                </Button>
                <Button variant="outline" size="sm" className="rounded-none">
                  2
                </Button>
                <Button variant="outline" size="sm" className="rounded-none">
                  3
                </Button>
                <Button variant="outline" size="sm" className="rounded-l-none">
                  Next
                </Button>
              </div>
            </div>
          </div>
        </div>

        <div className="space-y-6">
          <div className="card">
            <h2 className="text-lg font-semibold mb-4">Quiz Performance</h2>
            <div className="h-64 w-full">
              <div className="relative h-full w-full">
                <div className="flex h-full">
                  <button className="flex flex-col justify-end items-center w-1/4 h-full px-1">
                    <div className="w-full bg-blue-500 h-[85%]"></div>
                    <p className="text-xs mt-2 text-center">Programming</p>
                  </button>
                  <button className="flex flex-col justify-end items-center w-1/4 h-full px-1">
                    <div className="w-full bg-cyan-500 h-[75%]"></div>
                    <p className="text-xs mt-2 text-center">Communication</p>
                  </button>
                  <button className="flex flex-col justify-end items-center w-1/4 h-full px-1">
                    <div className="w-full bg-indigo-500 h-[90%]"></div>
                    <p className="text-xs mt-2 text-center">Critical Thinking</p>
                  </button>
                  <button className="flex flex-col justify-end items-center w-1/4 h-full px-1">
                    <div className="w-full bg-pink-500 h-[80%]"></div>
                    <p className="text-xs mt-2 text-center">Problem Solving</p>
                  </button>
                </div>
                <div className="absolute left-0 top-0 h-full border-l border-gray-200"></div>
                <div className="absolute bottom-0 left-0 w-full border-b border-gray-200"></div>
              </div>
            </div>
          </div>

          <div className="card">
            <h2 className="text-lg font-semibold mb-4">Your Achievements</h2>
            <div className="space-y-3">
              <Dialog>
                <DialogTrigger>
                  <button className="flex items-center p-3 border rounded-lg hover:bg-muted transition-colors w-full text-left">
                    <div className="flex items-center justify-center w-8 h-8 rounded-full bg-blue-500 text-white mr-3">
                      <Code className="h-4 w-4" />
                    </div>
                    <div>
                      <h3 className="text-sm font-medium">JavaScript Basics</h3>
                      <p className="text-xs text-muted-foreground">Completed on May 1, 2023</p>
                    </div>
                  </button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>JavaScript Basics Achievement</DialogTitle>
                  </DialogHeader>
                  <div className="space-y-4 py-4">
                    <div className="flex justify-center">
                      <div className="flex items-center justify-center w-16 h-16 rounded-full bg-blue-500 text-white">
                        <Code className="h-8 w-8" />
                      </div>
                    </div>
                    <h3 className="text-xl font-bold text-center">JavaScript Basics</h3>
                    <p className="text-center">Completed on May 1, 2023</p>
                    <div className="text-center">
                      <span className="text-2xl font-bold">85%</span>
                      <p className="text-sm text-muted-foreground">Score: 17/20 questions</p>
                    </div>
                    <div className="space-y-2">
                      <h4 className="font-medium">Topics Covered:</h4>
                      <ul className="list-disc pl-5 space-y-1 text-sm">
                        <li>Variables and Data Types</li>
                        <li>Functions and Scope</li>
                        <li>Arrays and Objects</li>
                        <li>DOM Manipulation</li>
                        <li>Event Handling</li>
                      </ul>
                    </div>
                    <Button className="w-full">Retake Quiz</Button>
                  </div>
                </DialogContent>
              </Dialog>

              <Dialog>
                <DialogTrigger>
                  <button className="flex items-center p-3 border rounded-lg hover:bg-muted transition-colors w-full text-left">
                    <div className="flex items-center justify-center w-8 h-8 rounded-full bg-purple-500 text-white mr-3">
                      <svg className="h-4 w-4" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M12 16L4 8L20 8L12 16Z" fill="currentColor" />
                      </svg>
                    </div>
                    <div>
                      <h3 className="text-sm font-medium">Learning How to Learn</h3>
                      <p className="text-xs text-muted-foreground">Completed on April 15, 2023</p>
                    </div>
                  </button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>Learning How to Learn Achievement</DialogTitle>
                  </DialogHeader>
                  <div className="space-y-4 py-4">
                    <div className="flex justify-center">
                      <div className="flex items-center justify-center w-16 h-16 rounded-full bg-purple-500 text-white">
                        <svg className="h-8 w-8" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                          <path d="M12 16L4 8L20 8L12 16Z" fill="currentColor" />
                        </svg>
                      </div>
                    </div>
                    <h3 className="text-xl font-bold text-center">Learning How to Learn</h3>
                    <p className="text-center">Completed on April 15, 2023</p>
                    <div className="text-center">
                      <span className="text-2xl font-bold">90%</span>
                      <p className="text-sm text-muted-foreground">Score: 18/20 questions</p>
                    </div>
                    <div className="space-y-2">
                      <h4 className="font-medium">Topics Covered:</h4>
                      <ul className="list-disc pl-5 space-y-1 text-sm">
                        <li>Focused vs Diffuse Thinking</li>
                        <li>Chunking</li>
                        <li>Procrastination and Memory</li>
                        <li>Learning Techniques</li>
                        <li>Test-Taking Strategies</li>
                      </ul>
                    </div>
                    <Button className="w-full">Retake Quiz</Button>
                  </div>
                </DialogContent>
              </Dialog>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
