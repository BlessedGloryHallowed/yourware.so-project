import PageHeader from "@/components/page-header"
import { Button } from "@/components/ui/button"
import { Award, Trophy, BookOpen, FileText } from "lucide-react"
import Image from "next/image"

export default function CertificatesPage() {
  return (
    <div className="flex flex-col min-h-screen">
      <PageHeader
        title="Certificates & Achievements"
        actions={
          <>
            <Button variant="outline" className="flex items-center gap-2">
              <span>Export All Certificates</span>
            </Button>
            <Button className="flex items-center gap-2">
              <span>Add Certificate</span>
            </Button>
          </>
        }
      />

      <div className="p-6">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <div className="card flex flex-col items-center text-center p-6">
            <div className="flex items-center justify-center w-16 h-16 rounded-full bg-blue-500 text-white mb-4">
              <Award className="h-8 w-8" />
            </div>

            <h2 className="text-xl font-semibold mb-2">My Certificates</h2>
            <p className="text-sm text-muted-foreground mb-4">View all earned certifications</p>

            <Button variant="outline" className="w-full">
              View All
            </Button>
          </div>

          <div className="card flex flex-col items-center text-center p-6">
            <div className="flex items-center justify-center w-16 h-16 rounded-full bg-green-500 text-white mb-4">
              <Trophy className="h-8 w-8" />
            </div>

            <h2 className="text-xl font-semibold mb-2">Achievements</h2>
            <p className="text-sm text-muted-foreground mb-4">Skills badges and recognitions</p>

            <Button variant="outline" className="w-full">
              View All
            </Button>
          </div>

          <div className="card flex flex-col items-center text-center p-6">
            <div className="flex items-center justify-center w-16 h-16 rounded-full bg-yellow-500 text-white mb-4">
              <BookOpen className="h-8 w-8" />
            </div>

            <h2 className="text-xl font-semibold mb-2">Courses Completed</h2>
            <p className="text-sm text-muted-foreground mb-4">All finished learning modules</p>

            <Button variant="outline" className="w-full">
              View All
            </Button>
          </div>

          <div className="card flex flex-col items-center text-center p-6">
            <div className="flex items-center justify-center w-16 h-16 rounded-full bg-red-500 text-white mb-4">
              <FileText className="h-8 w-8" />
            </div>

            <h2 className="text-xl font-semibold mb-2">Progress Summary</h2>
            <p className="text-sm text-muted-foreground mb-4">Overall achievement status</p>

            <Button variant="outline" className="w-full">
              View Report
            </Button>
          </div>
        </div>

        <div className="card">
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-lg font-semibold">Recent Certificates</h2>

            <div className="w-48">
              <select className="select">
                <option>All Certificates</option>
                <option>Technical</option>
                <option>Soft Skills</option>
                <option>Career</option>
              </select>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="flex flex-col items-center">
              <div className="mb-4">
                <Image
                  src="/placeholder.svg?height=200&width=200"
                  alt="Certificate"
                  width={200}
                  height={200}
                  className="rounded-lg"
                />
              </div>
              <h3 className="font-medium text-center">Introduction to Web Development</h3>
            </div>

            <div className="flex flex-col items-center">
              <div className="mb-4">
                <Image
                  src="/placeholder.svg?height=200&width=200"
                  alt="Certificate"
                  width={200}
                  height={200}
                  className="rounded-lg"
                />
              </div>
              <h3 className="font-medium text-center">Professional Communication</h3>
            </div>

            <div className="flex flex-col items-center">
              <div className="mb-4">
                <Image
                  src="/placeholder.svg?height=200&width=200"
                  alt="Certificate"
                  width={200}
                  height={200}
                  className="rounded-lg"
                />
              </div>
              <h3 className="font-medium text-center">Python for Data Science</h3>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
