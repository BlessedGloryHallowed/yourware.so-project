import PageHeader from "@/components/page-header"
import { Button } from "@/components/ui/button"
import { Play, Info, X } from "lucide-react"

export default function ProgressPage() {
  return (
    <div className="flex flex-col min-h-screen">
      <PageHeader
        title="Study Progress"
        actions={
          <Button className="flex items-center gap-2">
            <span>Add New Course</span>
          </Button>
        }
      />

      <div className="grid md:grid-cols-3 gap-6 p-6">
        <div className="card">
          <h2 className="text-lg font-semibold mb-4">Learning Overview</h2>

          <div className="flex flex-col items-center justify-center py-6">
            <div className="text-6xl font-bold">76%</div>
            <div className="text-sm text-muted-foreground mt-2">Overall Completion</div>

            <div className="grid grid-cols-3 w-full mt-8 text-center">
              <div className="flex flex-col items-center">
                <div className="text-2xl font-bold">5</div>
                <div className="text-xs text-muted-foreground">Active Courses</div>
              </div>

              <div className="flex flex-col items-center">
                <div className="text-2xl font-bold">12</div>
                <div className="text-xs text-muted-foreground">Completed</div>
              </div>

              <div className="flex flex-col items-center">
                <div className="text-2xl font-bold text-green-500">+15%</div>
                <div className="text-xs text-muted-foreground">This Month</div>
              </div>
            </div>
          </div>
        </div>

        <div className="md:col-span-2">
          <div className="card">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-lg font-semibold">Current Courses</h2>

              <div className="w-48">
                <select className="select">
                  <option>All Courses</option>
                  <option>In Progress</option>
                  <option>Completed</option>
                </select>
              </div>
            </div>

            <div className="space-y-8">
              <div>
                <div className="flex justify-between items-center mb-2">
                  <h3 className="font-medium">Introduction to Web Development</h3>
                  <span className="inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-semibold bg-green-500 text-white">
                    In Progress
                  </span>
                </div>

                <div className="grid grid-cols-2 gap-4 mb-2">
                  <div>
                    <div className="text-sm text-muted-foreground">Platform</div>
                    <div>Coursera</div>
                  </div>
                  <div>
                    <div className="text-sm text-muted-foreground">Duration</div>
                    <div>6 weeks</div>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4 mb-4">
                  <div>
                    <div className="text-sm text-muted-foreground">Started: May 12, 2023</div>
                  </div>
                  <div>
                    <div className="text-sm text-muted-foreground">Est. completion: Jun 24, 2023</div>
                  </div>
                </div>

                <div className="w-full bg-gray-200 rounded-full h-2 mb-4">
                  <div className="bg-blue-500 h-2 rounded-full" style={{ width: "75%" }}></div>
                </div>

                <div className="flex justify-between items-center">
                  <div>
                    <span className="text-sm font-medium">Completion</span>
                    <span className="text-sm font-medium ml-2">75%</span>
                  </div>

                  <div className="flex gap-2">
                    <Button variant="default" size="sm" className="flex items-center gap-1">
                      <Play className="h-4 w-4" />
                      <span>Continue</span>
                    </Button>
                    <Button variant="outline" size="sm" className="flex items-center gap-1">
                      <Info className="h-4 w-4" />
                      <span>Details</span>
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      className="flex items-center gap-1 text-red-500 border-red-200 hover:bg-red-50"
                    >
                      <X className="h-4 w-4" />
                      <span>Remove</span>
                    </Button>
                  </div>
                </div>
              </div>

              <div>
                <div className="flex justify-between items-center mb-2">
                  <h3 className="font-medium">Professional Communication Skills</h3>
                  <span className="inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-semibold bg-green-500 text-white">
                    In Progress
                  </span>
                </div>

                <div className="grid grid-cols-2 gap-4 mb-2">
                  <div>
                    <div className="text-sm text-muted-foreground">Platform</div>
                    <div>LinkedIn Learning</div>
                  </div>
                  <div>
                    <div className="text-sm text-muted-foreground">Duration</div>
                    <div>4 weeks</div>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4 mb-4">
                  <div>
                    <div className="text-sm text-muted-foreground">Started: May 5, 2023</div>
                  </div>
                  <div>
                    <div className="text-sm text-muted-foreground">Est. completion: Jun 2, 2023</div>
                  </div>
                </div>

                <div className="w-full bg-gray-200 rounded-full h-2 mb-4">
                  <div className="bg-cyan-500 h-2 rounded-full" style={{ width: "45%" }}></div>
                </div>

                <div className="flex justify-between items-center">
                  <div>
                    <span className="text-sm font-medium">Completion</span>
                    <span className="text-sm font-medium ml-2">45%</span>
                  </div>

                  <div className="flex gap-2">
                    <Button variant="default" size="sm" className="flex items-center gap-1">
                      <Play className="h-4 w-4" />
                      <span>Continue</span>
                    </Button>
                    <Button variant="outline" size="sm" className="flex items-center gap-1">
                      <Info className="h-4 w-4" />
                      <span>Details</span>
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      className="flex items-center gap-1 text-red-500 border-red-200 hover:bg-red-50"
                    >
                      <X className="h-4 w-4" />
                      <span>Remove</span>
                    </Button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="md:col-span-3">
          <div className="card">
            <h2 className="text-lg font-semibold mb-4">Quick Actions</h2>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <Button variant="outline" className="flex items-center justify-center gap-2 h-12">
                <Play className="h-4 w-4" />
                <span>Resume Learning</span>
              </Button>

              <Button variant="outline" className="flex items-center justify-center gap-2 h-12">
                <svg className="h-4 w-4" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path
                    d="M9 17L4 12M4 12L9 7M4 12H20"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  />
                </svg>
                <span>Track Progress</span>
              </Button>

              <Button variant="outline" className="flex items-center justify-center gap-2 h-12">
                <svg className="h-4 w-4" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path
                    d="M21 21L15 15M17 10C17 13.866 13.866 17 10 17C6.13401 17 3 13.866 3 10C3 6.13401 6.13401 3 10 3C13.866 3 17 6.13401 17 10Z"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  />
                </svg>
                <span>Find New Courses</span>
              </Button>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
